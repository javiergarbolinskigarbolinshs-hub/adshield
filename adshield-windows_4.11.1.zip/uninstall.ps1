﻿# AdShield deinstallieren
Add-Type -AssemblyName System.Windows.Forms
$dest = Join-Path $env:LOCALAPPDATA "AdShield"
$r = [System.Windows.Forms.MessageBox]::Show("AdShield wirklich entfernen?`n`nDanach musst du AdShield noch in Chrome unter chrome://extensions entfernen.", "AdShield", "YesNo", "Question")
if ($r -ne "Yes") { exit 0 }
foreach ($t in @((Join-Path ([Environment]::GetFolderPath("Desktop")) "AdShield.lnk"), (Join-Path ([Environment]::GetFolderPath("Programs")) "AdShield.lnk"))) {
  if (Test-Path $t) { Remove-Item -Force $t }
}
Start-Process "cmd.exe" -ArgumentList "/c timeout /t 2 >nul & rmdir /s /q `"$dest`"" -WindowStyle Hidden
