﻿# AdShield - Installation fuer Windows (ohne Administrator-Rechte)
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA "AdShield"

New-Item -ItemType Directory -Force -Path $dest | Out-Null
if (Test-Path (Join-Path $dest "extension")) { Remove-Item -Recurse -Force (Join-Path $dest "extension") }
Copy-Item -Recurse -Force (Join-Path $src "extension") (Join-Path $dest "extension")
foreach ($f in @("adshield.ps1", "adshield.ico", "update.wav", "update.conf", "uninstall.ps1")) {
  if (Test-Path (Join-Path $src $f)) { Copy-Item -Force (Join-Path $src $f) (Join-Path $dest $f) }
}

# Verknuepfungen (Desktop + Startmenue)
$ws = New-Object -ComObject WScript.Shell
$targets = @(
  (Join-Path ([Environment]::GetFolderPath("Desktop")) "AdShield.lnk"),
  (Join-Path ([Environment]::GetFolderPath("Programs")) "AdShield.lnk")
)
foreach ($t in $targets) {
  $s = $ws.CreateShortcut($t)
  $s.TargetPath = "powershell.exe"
  $s.Arguments  = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\adshield.ps1`""
  $s.IconLocation = "$dest\adshield.ico"
  $s.WorkingDirectory = $dest
  $s.Description = "AdShield - Werbeblocker"
  $s.Save()
}

[System.Windows.Forms.MessageBox]::Show("AdShield wurde installiert.`n`nAuf deinem Desktop liegt jetzt das AdShield-Symbol. Es startet gleich und zeigt dir, wie du AdShield einmal in Chrome aktivierst.", "AdShield", "OK", "Information") | Out-Null
Start-Process "powershell.exe" -ArgumentList "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\adshield.ps1`""
