@echo off
rem AdShield installieren - einfach doppelklicken (die ZIP-Datei vorher entpacken!)
title AdShield installieren
if not exist "%~dp0install.ps1" (
  echo Bitte zuerst die ZIP-Datei entpacken:
  echo Rechtsklick auf die ZIP-Datei, dann "Alle extrahieren", und danach diese Datei im neuen Ordner doppelklicken.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Die Installation ist fehlgeschlagen. Bitte mach ein Foto von diesem Fenster.
  pause
)
