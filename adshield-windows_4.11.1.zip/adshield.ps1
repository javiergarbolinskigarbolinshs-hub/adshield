﻿# AdShield - Starter fuer Windows
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$AppDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExtDir  = Join-Path $AppDir "extension"
$ExtId   = "heoondlgnolbgkomebnkajachjhdlekh"
$HomeUrl = "chrome-extension://$ExtId/home.html"
$DataDir = Join-Path $env:APPDATA "adshield"
$German  = ((Get-UICulture).TwoLetterISOLanguageName -eq "de")

function T($de, $en) { if ($German) { return $de } else { return $en } }
function Msg($text, $icon = "Information", $buttons = "OK") {
  return [System.Windows.Forms.MessageBox]::Show($text, "AdShield", $buttons, $icon)
}

# Neuer Starter von einem frueheren Update uebernehmen
$newSelf = Join-Path $AppDir "adshield.ps1.new"
if (Test-Path $newSelf) {
  try { Move-Item -Force $newSelf (Join-Path $AppDir "adshield.ps1") } catch {}
}

function Get-InstalledVersion {
  try { return (Get-Content (Join-Path $ExtDir "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch { return "0.0.0" }
}

function Find-Chrome {
  $paths = @(
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
  )
  foreach ($p in $paths) { if ($p -and (Test-Path $p)) { return $p } }
  try {
    $v = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" -ErrorAction Stop).'(default)'
    if ($v -and (Test-Path $v)) { return $v }
  } catch {}
  return $null
}

function Test-ExtensionInstalled {
  $root = Join-Path $env:LOCALAPPDATA "Google\Chrome\User Data"
  if (-not (Test-Path $root)) { return $false }
  foreach ($d in (Get-ChildItem $root -Directory -ErrorAction SilentlyContinue)) {
    foreach ($n in @("Secure Preferences", "Preferences")) {
      $p = Join-Path $d.FullName $n
      if (Test-Path $p) {
        try { if (Select-String -Path $p -Pattern $ExtId -Quiet) { return $true } } catch {}
      }
    }
  }
  return $false
}

# ---------- Musik beim Aktualisieren ----------
$script:Wmp = $null
$script:Player = $null
function Start-Music {
  try {
    $custom = $null
    foreach ($n in @("update.mp3", "update.wav", "update.wma")) {
      $c = Join-Path $DataDir $n
      if (Test-Path $c) { $custom = $c; break }
    }
    if ($custom) {
      $w = New-Object -ComObject WMPlayer.OCX
      $w.settings.setMode("loop", $true)
      $w.URL = $custom
      $w.controls.play()
      $script:Wmp = $w
      return
    }
    $wav = Join-Path $AppDir "update.wav"
    if (Test-Path $wav) {
      $p = New-Object System.Media.SoundPlayer $wav
      $p.PlayLooping()
      $script:Player = $p
    }
  } catch {}
}
function Stop-Music {
  try { if ($script:Wmp) { $script:Wmp.controls.stop(); $script:Wmp.close() } } catch {}
  try { if ($script:Player) { $script:Player.Stop() } } catch {}
  $script:Wmp = $null
  $script:Player = $null
}

# ---------- Fortschrittsfenster ----------
function New-ProgressForm {
  $f = New-Object System.Windows.Forms.Form
  $f.Text = "AdShield"
  $f.Width = 470
  $f.Height = 170
  $f.StartPosition = "CenterScreen"
  $f.FormBorderStyle = "FixedDialog"
  $f.MaximizeBox = $false
  $f.MinimizeBox = $false
  $f.ControlBox = $false
  $f.TopMost = $true
  $l = New-Object System.Windows.Forms.Label
  $l.Left = 20; $l.Top = 20; $l.Width = 420; $l.Height = 40
  $b = New-Object System.Windows.Forms.ProgressBar
  $b.Left = 20; $b.Top = 70; $b.Width = 420; $b.Height = 24
  $b.Minimum = 0; $b.Maximum = 100
  $f.Controls.Add($l)
  $f.Controls.Add($b)
  $f.Tag = @{ Label = $l; Bar = $b }
  return $f
}
function Set-Progress($f, $pct, $text) {
  $f.Tag.Label.Text = $text
  $v = [int][Math]::Max(0, [Math]::Min(100, $pct))
  $f.Tag.Bar.Value = $v
  [System.Windows.Forms.Application]::DoEvents()
}
function Get-EtaText($secs) {
  $s = [int][Math]::Ceiling($secs)
  if ($s -le 3) { return (T "gleich fertig" "almost done") }
  if ($s -lt 60) { return (T "noch etwa $s Sekunden" "about $s seconds left") }
  $m = [int][Math]::Round($s / 60)
  return (T "noch etwa $m Min." "about $m min left")
}

function Show-UpdateFailed($form, $reason, $cur) {
  Stop-Music
  if ($form) { try { $form.Close() } catch {} }
  Msg (T "Aktualisierung fehlgeschlagen`n`nEs konnte nicht aktualisiert werden.`n`nGrund: $reason`n`nAdShield bleibt auf Version $cur und funktioniert ganz normal weiter. Du kannst es später noch einmal versuchen." "Update failed`n`nThe update could not be installed.`n`nReason: $reason`n`nAdShield stays on version $cur and keeps working normally. You can try again later.") "Error" | Out-Null
}

# ---------- Aktualisierung ----------
function Invoke-UpdateCheck {
  $conf = Join-Path $AppDir "update.conf"
  if (-not (Test-Path $conf)) { return }
  $url = ""
  foreach ($line in (Get-Content $conf)) {
    if ($line -match '^\s*UPDATE_URL\s*=\s*"?([^"]+)"?\s*$') { $url = $Matches[1].Trim() }
  }
  if (-not $url.StartsWith("https://")) { return }

  try {
    $info = Invoke-RestMethod -Uri $url -TimeoutSec 6 -UseBasicParsing
    if ($info -is [string]) { $info = $info | ConvertFrom-Json }
  } catch { return }
  if (-not $info.version -or -not $info.win_zip) { return }

  $cur = Get-InstalledVersion
  try { if ([version]$info.version -le [version]$cur) { return } } catch { return }

  $notes = ""
  if ($info.notes) { $notes = "`n`n" + $info.notes }
  $q = Msg (T "Neue Aktualisierung gefunden!`n`nVersion $cur  ->  $($info.version)$notes`n`nSoll ich AdShield jetzt aktualisieren?" "New update found!`n`nVersion $cur  ->  $($info.version)$notes`n`nDo you want to update AdShield now?") "Question" "YesNo"
  if ($q -ne "Yes") { return }

  $base = $url.Substring(0, $url.LastIndexOf("/") + 1)
  if ($info.win_zip.StartsWith("https://")) { $zipUrl = $info.win_zip } else { $zipUrl = $base + $info.win_zip }

  $form = New-ProgressForm
  $form.Show()
  Set-Progress $form 0 (T "Aktualisierung wird vorbereitet ..." "Preparing the update ...")
  Start-Music

  $tmp = Join-Path $env:TEMP ("adshield-update-" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  $zip = Join-Path $tmp "adshield.zip"

  # 1. Herunterladen
  try {
    $req = [System.Net.HttpWebRequest]::Create($zipUrl)
    $req.Timeout = 15000
    $req.ReadWriteTimeout = 30000
    $resp = $req.GetResponse()
    $total = $resp.ContentLength
    $st = $resp.GetResponseStream()
    $fs = [System.IO.File]::Create($zip)
    $buf = New-Object byte[] 65536
    $read = 0
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $last = 0
    while (($n = $st.Read($buf, 0, $buf.Length)) -gt 0) {
      $fs.Write($buf, 0, $n)
      $read += $n
      if (($sw.ElapsedMilliseconds - $last) -gt 150) {
        $last = $sw.ElapsedMilliseconds
        if ($total -gt 0) {
          $pct = $read * 85 / $total
          $secs = $sw.Elapsed.TotalSeconds
          $eta = 0
          if ($secs -gt 1 -and $read -gt 0) { $eta = ($total - $read) / ($read / $secs) }
          $shown = [int]($read * 100 / $total)
          Set-Progress $form $pct ((T "Lade herunter ... " "Downloading ... ") + $shown + " %  -  " + (Get-EtaText $eta))
        } else {
          Set-Progress $form 40 (T "Lade herunter ..." "Downloading ...")
        }
      }
    }
    $fs.Close(); $st.Close(); $resp.Close()
  } catch {
    $m = $_.Exception.Message
    if ($m -match "404") { $reason = T "Die Datei wurde auf dem Server nicht gefunden." "The file was not found on the server." }
    elseif ($m -match "(?i)remote name|Remotename|resolved|aufgel|connect|verbind|unable") { $reason = T "Keine Internetverbindung (der Server ist nicht erreichbar)." "No internet connection (the server cannot be reached)." }
    else { $reason = (T "Das Herunterladen hat nicht geklappt." "The download failed.") + " (" + $m + ")" }
    Show-UpdateFailed $form $reason $cur
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
    return
  }

  # 2. Pruefen
  Set-Progress $form 88 (T "Prüfe die heruntergeladene Datei ..." "Checking the downloaded file ...")
  if ($info.win_sha256) {
    $h = (Get-FileHash -Algorithm SHA256 -Path $zip).Hash.ToLower()
    if ($h -ne $info.win_sha256.ToString().ToLower()) {
      Show-UpdateFailed $form (T "Die heruntergeladene Datei ist beschädigt oder wurde verändert. Es wurde nichts installiert." "The downloaded file is damaged or was modified. Nothing was installed.") $cur
      Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
      return
    }
  }

  # 3. Installieren
  try {
    Set-Progress $form 92 (T "Installiere ..." "Installing ...")
    $x = Join-Path $tmp "x"
    Expand-Archive -Path $zip -DestinationPath $x -Force
    $newExt = Join-Path $x "extension"
    if (-not (Test-Path (Join-Path $newExt "manifest.json"))) { throw "Paket unvollständig" }
    if (Test-Path $ExtDir) { Remove-Item -Recurse -Force $ExtDir }
    Copy-Item -Recurse -Force $newExt $ExtDir
    foreach ($f in @("adshield.ico", "update.wav", "update.conf", "uninstall.ps1")) {
      if (Test-Path (Join-Path $x $f)) { Copy-Item -Force (Join-Path $x $f) (Join-Path $AppDir $f) }
    }
    if (Test-Path (Join-Path $x "adshield.ps1")) { Copy-Item -Force (Join-Path $x "adshield.ps1") (Join-Path $AppDir "adshield.ps1.new") }
    Set-Progress $form 100 (T "Fertig!" "Done!")
    Start-Sleep -Milliseconds 800
  } catch {
    Show-UpdateFailed $form ((T "Die Installation ist fehlgeschlagen." "The installation failed.") + " (" + $_.Exception.Message + ")") $cur
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
    return
  }
  Stop-Music
  $form.Close()
  Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  Msg (T "AdShield wurde auf Version $($info.version) aktualisiert.`n`nSo wird die neue Version aktiv:`n`n  1. Google Chrome ganz schließen (alle Fenster).`n  2. Danach noch einmal auf das AdShield-Symbol klicken." "AdShield was updated to version $($info.version).`n`nTo activate the new version:`n`n  1. Close Google Chrome completely (all windows).`n  2. Then click the AdShield icon again.") | Out-Null
  exit 0
}

# ---------- Start ----------
try { Invoke-UpdateCheck } catch {
  Stop-Music
}

$chrome = Find-Chrome
if (-not $chrome) {
  Msg (T "AdShield braucht Google Chrome.`n`nInstalliere Chrome von google.com/chrome und klicke dann noch einmal auf AdShield." "AdShield needs Google Chrome.`n`nInstall Chrome from google.com/chrome and then click AdShield again.") "Error" | Out-Null
  exit 1
}

if (-not (Test-ExtensionInstalled)) {
  try { Set-Clipboard -Value $ExtDir } catch {}
  Msg (T "AdShield einrichten - nur einmal`n`nGoogle Chrome öffnet gleich die Seite Erweiterungen. Dort:`n`n  1. Oben rechts den Entwicklermodus einschalten.`n  2. Auf 'Entpackte Erweiterung laden' klicken.`n  3. Diesen Ordner auswählen (der Pfad ist schon kopiert, du kannst ihn mit Strg+V einfügen):`n`n$ExtDir`n`nDanach startet das AdShield-Tutorial von selbst. Ab dann öffnet dieses Symbol direkt AdShield." "Set up AdShield - only once`n`nGoogle Chrome will open the Extensions page. There:`n`n  1. Turn on Developer mode (top right).`n  2. Click 'Load unpacked'.`n  3. Select this folder (the path is already copied, paste it with Ctrl+V):`n`n$ExtDir`n`nThe AdShield tutorial then starts by itself. From then on, this icon opens AdShield directly.") | Out-Null
  Start-Process $chrome -ArgumentList "chrome://extensions/"
  exit 0
}

Start-Process $chrome -ArgumentList @("--new-window", $HomeUrl)
