AdShield für macOS (Google Chrome)
==================================

1. "AdShield.app" in den Ordner "Programme" ziehen (geht auch von jedem anderen Ort).
2. Beim ERSTEN Start: AdShield ist nicht bei Apple signiert, darum blockt macOS es einmal.
   • macOS 14 oder älter: Rechtsklick (Control-Klick) auf AdShield.app → "Öffnen" → "Öffnen".
   • macOS 15 (Sequoia) oder neuer: Doppelklick (wird abgelehnt), dann
     Systemeinstellungen → Datenschutz & Sicherheit → ganz unten "Trotzdem öffnen".
3. AdShield erklärt dann einmal, wie es in Google Chrome hinzugefügt wird
   (Entwicklermodus an → "Entpackte Erweiterung laden" → Ordner "AdShield" im Benutzerordner).
4. Fertig. Ab jetzt öffnet das AdShield-Symbol direkt den Blocker.

Aktualisierung: AdShield fragt beim Start "Jetzt aktualisieren – Ja oder Nein?".
Eigene Update-Musik: Datei "update.mp3" nach
  ~/Library/Application Support/AdShield/   legen.

Entfernen: AdShield.app in den Papierkorb, Ordner "AdShield" im Benutzerordner löschen,
in Chrome unter chrome://extensions AdShield entfernen.

Hinweis: Diese Mac-Version ist neu und wurde noch nicht auf einem echten Mac getestet.
Fehler bitte melden – dann wird es repariert.
