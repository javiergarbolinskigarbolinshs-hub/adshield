const DEFAULTS = { enabled: true, google: true, youtube: true, ytmusic: true, soundcloud: true, other: true };
const $ = (id) => document.getElementById(id);
let tabId = null;

async function renderSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $("enabled").checked = s.enabled;
  $("app").classList.toggle("off", !s.enabled);
  document.querySelectorAll("[data-key]").forEach((i) => { i.checked = s[i.dataset.key]; });
}

async function renderStats() {
  const today = new Date().toISOString().slice(0, 10);
  const st = await chrome.storage.local.get({ total: 0, today: 0, day: today });
  $("total").textContent = UI.fmt(st.total);
  $("today").textContent = UI.fmt(st.day === today ? st.today : 0);
  if (tabId != null) {
    const key = `tab_${tabId}`;
    $("tab").textContent = UI.fmt((await chrome.storage.session.get({ [key]: 0 }))[key]);
  }
}

async function renderDiag() {
  if (tabId == null) return;
  const key = `net_${tabId}`;
  const log = (await chrome.storage.session.get({ [key]: {} }))[key];
  const { allowHosts = [] } = await chrome.storage.local.get("allowHosts");
  const hosts = Object.keys(log).sort((a, b) => log[b].n - log[a].n);
  $("diagN").textContent = hosts.length;
  const ul = $("diagList");
  ul.textContent = "";
  if (!hosts.length) { const li = document.createElement("li"); li.className = "empty"; li.textContent = UI.t("diag_empty"); ul.appendChild(li); return; }
  for (const h of hosts) {
    const li = document.createElement("li");
    const name = document.createElement("span");
    name.className = "host"; name.title = log[h].sample;
    name.textContent = h + " (" + log[h].n + "× " + UI.t(log[h].stub ? "diag_stub" : "diag_block") + ")";
    const btn = document.createElement("button");
    const ok = allowHosts.includes(h);
    btn.type = "button"; btn.className = "mini" + (ok ? " on" : "");
    btn.textContent = UI.t(ok ? "diag_allowed" : "diag_allow");
    btn.addEventListener("click", async () => {
      const cur = (await chrome.storage.local.get({ allowHosts: [] })).allowHosts;
      await chrome.storage.local.set({ allowHosts: ok ? cur.filter((x) => x !== h) : [...cur, h] });
      renderDiag();
    });
    li.append(name, btn);
    ul.appendChild(li);
  }
}

async function renderStatus() {
  const st = await UI.getStatus();
  UI.setLight($("light"), st.level);
  $("status").textContent = UI.t("status_" + st.level);
  const n = $("notice");
  if (st.level === "green" || !st.issues.length) { n.hidden = true; return; }
  n.hidden = false;
  n.dataset.level = st.level;
  const first = st.issues.find((i) => i.sev === "error") || st.issues[0];
  $("noticeText").textContent = UI.issueText(first);
}

const openPage = (page) => { chrome.tabs.create({ url: chrome.runtime.getURL(page) }); window.close(); };

$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
document.querySelectorAll("[data-key]").forEach((i) => {
  i.addEventListener("change", () => chrome.storage.sync.set({ [i.dataset.key]: i.checked }));
});
$("home").addEventListener("click", () => openPage("home.html"));
$("settings").addEventListener("click", () => openPage("settings.html"));
$("notice").addEventListener("click", () => openPage("settings.html#status"));

chrome.storage.onChanged.addListener((c, area) => {
  if (area === "sync") renderSettings();
  else if (c.status) renderStatus();
  else renderStats();
});

(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id ?? null;
  } catch (e) { /* kein Tab */ }
  await UI.init();
  UI.onLang(() => { renderStatus(); renderStats(); renderDiag(); });
  renderSettings();
  renderStats();
  renderStatus();
  renderDiag();
  $("diag").addEventListener("toggle", renderDiag);
})();

// Geheimer Zugang: 5× schnell aufs Schild klicken
(() => {
  let n = 0, t = null;
  const logo = document.querySelector(".logo");
  if (!logo) return;
  logo.style.cursor = "pointer";
  logo.addEventListener("click", async () => {
    n++; clearTimeout(t); t = setTimeout(() => { n = 0; }, 1500);
    logo.animate([{ transform: "scale(1)" }, { transform: `scale(${1 + n * 0.08})` }, { transform: "scale(1)" }], { duration: 200 });
    if (n >= 5) {
      n = 0;
      let url = "";
      try { url = (await chrome.tabs.get(tabId)).url || ""; } catch (e) {}
      chrome.runtime.sendMessage({ type: "open-dev-active", tabId, url });
      setTimeout(() => window.close(), 150);
    }
  });
})();
