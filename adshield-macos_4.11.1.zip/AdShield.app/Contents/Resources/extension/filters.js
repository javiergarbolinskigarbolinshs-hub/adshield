// Wandelt Adblock-Filterlisten (EasyList / uBlock-Syntax) in
// Chrome-Netzwerkregeln und Ausblende-Selektoren für unsere Seiten um.
// Läuft im Hintergrund (importScripts) und ist auch in Node testbar.

const FILTER_LISTS = [
  {
    id: "easylist",
    name: "EasyList",
    urls: [
      "https://easylist.to/easylist/easylist.txt",
      "https://ublockorigin.github.io/uAssets/thirdparties/easylist.txt"
    ]
  },
  {
    id: "easylistgermany",
    name: "EasyList Germany",
    urls: [
      "https://easylist.to/easylistgermany/easylistgermany.txt",
      "https://easylist-downloads.adblockplus.org/easylistgermany.txt"
    ]
  },
  {
    id: "ublock",
    name: "uBlock Filters",
    urls: [
      "https://ublockorigin.github.io/uAssets/filters/filters.txt",
      "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt"
    ]
  },
  {
    id: "quickfixes",
    name: "uBlock Quick Fixes",
    urls: [
      "https://ublockorigin.github.io/uAssets/filters/quick-fixes.txt",
      "https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/quick-fixes.txt"
    ]
  }
];

// Für Ausblende-Regeln: auf welche Seiten passen sie?
const SITE_HOSTS = {
  google: ["www.google.com", "www.google.de", "www.google.at", "www.google.ch", "www.google.pl"],
  youtube: ["www.youtube.com", "m.youtube.com"],
  ytmusic: ["music.youtube.com"],
  soundcloud: ["soundcloud.com"]
};

// Für Netzwerkregeln: diese Seiten ausnehmen, wenn sie ausgeschaltet sind
const SITE_DOMAINS = {
  google: ["google.com", "google.de", "google.at", "google.ch", "google.pl", "google.co.uk",
           "google.fr", "google.nl", "google.it", "google.es"],
  youtube: ["www.youtube.com", "m.youtube.com"],
  ytmusic: ["music.youtube.com"],
  soundcloud: ["soundcloud.com"]
};

const MAX_NETWORK_RULES = 25000;
const MAX_COSMETIC_PER_SITE = 3000;

const TYPE_MAP = {
  script: "script", image: "image", stylesheet: "stylesheet", css: "stylesheet",
  xmlhttprequest: "xmlhttprequest", xhr: "xmlhttprequest",
  subdocument: "sub_frame", frame: "sub_frame",
  media: "media", font: "font", ping: "ping", beacon: "ping",
  object: "object", websocket: "websocket", other: "other"
};

// Selektor-Erweiterungen, die normales CSS nicht kann
const PROCEDURAL = /:(-abp-|has-text|upward|remove|style|matches-|xpath|min-text-length|watch-attr|others|if|if-not|nth-ancestor|contains)\b|^\^|^\+js/;

const DOMAIN_RE = /^[a-z0-9.-]+$/;

function hostMatches(entry, host) {
  const parts = host.split(".");
  for (let i = 0; i < parts.length - 1; i++) {
    const cand = parts.slice(i).join(".");
    if (cand === entry) return true;
    if (entry.endsWith(".*") && cand.startsWith(entry.slice(0, -1))) return true;
  }
  return false;
}

function sitesForDomains(domainList) {
  const entries = domainList.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean);
  const pos = entries.filter((d) => !d.startsWith("~"));
  const neg = entries.filter((d) => d.startsWith("~")).map((d) => d.slice(1));
  const out = [];
  for (const [key, hosts] of Object.entries(SITE_HOSTS)) {
    const ok = hosts.some((h) => pos.some((p) => hostMatches(p, h)) && !neg.some((n) => hostMatches(n, h)));
    if (ok) out.push(key);
  }
  return out;
}

// Eine Netzwerk-Zeile in eine Chrome-Regel umwandeln (oder null)
function parseNetwork(line) {
  let allow = false;
  if (line.startsWith("@@")) { allow = true; line = line.slice(2); }

  let pattern = line;
  let opts = "";
  const dollar = line.lastIndexOf("$");
  if (dollar > 0) { pattern = line.slice(0, dollar); opts = line.slice(dollar + 1); }

  if (!pattern || pattern.startsWith("||*") || pattern.startsWith("||/") || /[^\x21-\x7e]/.test(pattern)) return null;
  // Allgemeine Muster (z. B. "/ads/banner"): nur wenn genug "echter" Text drin ist
  const core = pattern.replace(/^\|\|?/, "").replace(/[*^|]/g, "");
  if (core.length < (pattern.startsWith("||") ? 3 : 4)) return null;

  const cond = { urlFilter: pattern, isUrlFilterCaseSensitive: false };
  const types = [];
  const excludedTypes = [];

  if (opts) {
    for (let opt of opts.split(",")) {
      opt = opt.trim().toLowerCase();
      if (!opt) continue;
      let neg = false;
      if (opt.startsWith("~")) { neg = true; opt = opt.slice(1); }

      if (opt === "third-party" || opt === "3p") { cond.domainType = neg ? "firstParty" : "thirdParty"; continue; }
      if (opt === "first-party" || opt === "1p") { cond.domainType = neg ? "thirdParty" : "firstParty"; continue; }
      if (opt === "important" || opt === "match-case") continue;
      if (opt.startsWith("domain=") || opt.startsWith("from=")) {
        const list = opt.slice(opt.indexOf("=") + 1).split("|");
        const inc = [], exc = [];
        for (let d of list) {
          const isNeg = d.startsWith("~");
          if (isNeg) d = d.slice(1);
          if (!DOMAIN_RE.test(d) || d.includes("*")) continue;
          (isNeg ? exc : inc).push(d);
        }
        if (inc.length) cond.initiatorDomains = inc;
        else if (list.some((d) => !d.startsWith("~"))) return null; // nur ungültige Domains übrig
        if (exc.length) cond.excludedInitiatorDomains = exc;
        continue;
      }
      if (TYPE_MAP[opt]) { (neg ? excludedTypes : types).push(TYPE_MAP[opt]); continue; }
      return null; // unbekannte/riskante Option (redirect, csp, popup, document …)
    }
  }
  if (types.length) cond.resourceTypes = [...new Set(types)];
  else if (excludedTypes.length) cond.excludedResourceTypes = [...new Set(excludedTypes)];

  return { action: allow ? "allow" : "block", priority: allow ? 2 : 1, condition: cond };
}

// Erhöhen, wenn sich der Parser ändert -> Listen werden neu verarbeitet
const PARSER_VERSION = 2;
const MAX_GENERIC_COSMETIC = 20000;

// Ganze Listen verarbeiten
function parseFilterLists(texts) {
  const allowRules = [], domainRules = [], genericRules = [];
  const seen = new Set();
  const cosmetic = { google: new Set(), youtube: new Set(), ytmusic: new Set(), soundcloud: new Set() };
  const cosmeticExceptions = { google: new Set(), youtube: new Set(), ytmusic: new Set(), soundcloud: new Set() };
  // Für alle anderen Webseiten
  const generic = new Set();
  const genericExceptions = new Set();
  const byDomain = {};
  const exceptByDomain = {};
  const add = (map, dom, sel) => { (map[dom] ||= []).push(sel); };
  const perList = {};

  for (const [id, text] of Object.entries(texts)) {
    let n = 0, c = 0;
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("!") || line.startsWith("[")) continue;

      // Ausblende-Regeln
      const m = line.match(/^([^#]*)#(@?)#(.+)$/);
      if (m) {
        const [, domains, exception, rawSel] = m;
        const selector = rawSel.trim();
        if (line.includes("#?#") || line.includes("#$#") || PROCEDURAL.test(selector)) continue;
        if (!domains) {
          (exception ? genericExceptions : generic).add(selector);
          if (!exception) c++;
          continue;
        }
        // unsere vier Seiten
        for (const key of sitesForDomains(domains)) {
          (exception ? cosmeticExceptions : cosmetic)[key].add(selector);
        }
        // jede andere Domain
        const entries = domains.split(",").map((d) => d.trim().toLowerCase()).filter(Boolean);
        for (const d of entries) {
          if (d.startsWith("~") || !/^[a-z0-9.*-]+$/.test(d)) continue;
          add(exception ? exceptByDomain : byDomain, d, selector);
        }
        // "überall außer ~x.com": als Ausnahme für x.com speichern
        const neg = entries.filter((d) => d.startsWith("~"));
        if (!exception && neg.length === entries.length) {
          generic.add(selector);
          for (const d of neg) add(exceptByDomain, d.slice(1), selector);
        }
        if (!exception) c++;
        continue;
      }
      if (/#[@?$%]#|#\+js/.test(line)) continue;

      // Netzwerkregeln
      if (line.startsWith("/") && line.endsWith("/")) continue; // Regex
      const rule = parseNetwork(line);
      if (!rule) continue;
      const key = JSON.stringify(rule);
      if (seen.has(key)) continue;
      seen.add(key);
      if (rule.action === "allow") allowRules.push(rule);
      else if (rule.condition.urlFilter.startsWith("||")) domainRules.push(rule);
      else genericRules.push(rule);
      n++;
    }
    perList[id] = { network: n, cosmetic: c };
  }

  // Ausnahmen zuerst, dann Domain-Regeln, dann allgemeine Muster
  const network = [...allowRules, ...domainRules, ...genericRules].slice(0, MAX_NETWORK_RULES);

  const cos = {};
  let cosmeticCount = 0;
  for (const key of Object.keys(cosmetic)) {
    cos[key] = [...cosmetic[key]].filter((s) => !cosmeticExceptions[key].has(s)).slice(0, MAX_COSMETIC_PER_SITE);
    cosmeticCount += cos[key].length;
  }

  const cosmeticAll = {
    generic: [...generic].filter((s) => !genericExceptions.has(s)).slice(0, MAX_GENERIC_COSMETIC),
    byDomain,
    exceptByDomain
  };
  cosmeticCount += cosmeticAll.generic.length + Object.values(byDomain).reduce((a, l) => a + l.length, 0);

  return { network, cosmetic: cos, cosmeticAll, perList, networkCount: network.length, cosmeticCount };
}

// Passende Ausblende-Regeln für einen Hostnamen (z. B. "gamebanana.com")
function cosmeticForHost(all, host) {
  if (!all) return [];
  const parts = host.toLowerCase().split(".");
  const keys = [];
  for (let i = 0; i < parts.length - 1; i++) {
    const cand = parts.slice(i).join(".");
    keys.push(cand);
    const dot = cand.indexOf(".");
    if (dot > 0) keys.push(cand.slice(0, dot) + ".*"); // z. B. "example.*"
  }
  const except = new Set(keys.flatMap((k) => all.exceptByDomain?.[k] || []));
  const specific = keys.flatMap((k) => all.byDomain?.[k] || []);
  return [...new Set([...all.generic, ...specific])].filter((s) => !except.has(s));
}

if (typeof module !== "undefined") {
  module.exports = { parseFilterLists, parseNetwork, sitesForDomains, cosmeticForHost, FILTER_LISTS, SITE_DOMAINS, PARSER_VERSION };
}
