const STEPS = 6;
const FILTER_STEP = 4;
const LIST_IDS = ["easylist", "easylistgermany", "ublock", "quickfixes"];
const LIST_NAMES = ["EasyList", "EasyList Germany", "uBlock Filters", "uBlock Quick Fixes"];
const SITE_DEFAULTS = { google: true, youtube: true, ytmusic: true, soundcloud: true, other: true };
const $ = (id) => document.getElementById(id);

let step = 0;
let filterState = "idle"; // idle | running | done | failed

// ---------- Navigation ----------
const dots = $("dots");
for (let i = 0; i < STEPS; i++) dots.append(document.createElement("i"));

function show(n) {
  const prev = step;
  step = Math.max(0, Math.min(STEPS - 1, n));
  document.querySelectorAll(".step").forEach((el) => {
    const i = Number(el.dataset.step);
    el.classList.toggle("active", i === step);
    el.classList.toggle("left", i < step);
  });
  [...dots.children].forEach((d, i) => {
    d.className = i === step ? "on" : i < step ? "done" : "";
  });
  $("back").style.visibility = step === 0 ? "hidden" : "visible";
  updateNext();
  if (step === FILTER_STEP && filterState === "idle") startFilters();
  if (step === STEPS - 1) celebrate();
  if (prev !== step) document.querySelector(`.step[data-step="${step}"]`).scrollTop = 0;
}

function updateNext() {
  const next = $("next");
  const key = step === 0 ? "ob_start" : step === STEPS - 1 ? "ob_finish" : "ob_next";
  next.dataset.i18n = key;
  next.textContent = UI.t(key);
  next.disabled = step === FILTER_STEP && filterState === "running";
}

async function finish() {
  await chrome.storage.local.set({ onboarded: true });
  location.replace("home.html");
}

$("next").addEventListener("click", () => (step === STEPS - 1 ? finish() : show(step + 1)));
$("back").addEventListener("click", () => show(step - 1));
$("skip").addEventListener("click", finish);
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowRight" && !$("next").disabled) $("next").click();
  if (e.key === "ArrowLeft" && step > 0) show(step - 1);
});

// ---------- Sprache ----------
function renderLang() {
  document.querySelectorAll("#langSeg button").forEach((b) => {
    b.setAttribute("aria-pressed", String(b.dataset.lang === UI.getLang()));
  });
  updateNext();
}
document.querySelectorAll("#langSeg button").forEach((b) => b.addEventListener("click", () => UI.setLang(b.dataset.lang)));

// ---------- Seiten ----------
async function renderSites() {
  const s = await chrome.storage.sync.get(SITE_DEFAULTS);
  document.querySelectorAll("[data-key]").forEach((i) => { i.checked = s[i.dataset.key]; });
}
document.querySelectorAll("[data-key]").forEach((i) => {
  i.addEventListener("change", () => chrome.storage.sync.set({ [i.dataset.key]: i.checked }));
});

// ---------- Filter laden ----------
const dl = $("dl");
LIST_NAMES.forEach((name) => {
  const li = document.createElement("li");
  li.innerHTML = `<span class="dot"></span><span class="nm"></span><span class="st"></span>`;
  li.querySelector(".nm").textContent = name;
  dl.append(li);
});

function setRing(pct, kind) {
  const ring = $("ring");
  ring.classList.remove("ok", "warn");
  if (kind) ring.classList.add(kind);
  $("ringFg").style.strokeDashoffset = String(327 - (327 * pct) / 100);
  $("ringNum").textContent = Math.round(pct) + "%";
}

function renderFilterState(u, lists) {
  const items = [...dl.children];
  if (u.running) {
    items.forEach((li, i) => {
      li.className = i < u.current ? "ok" : i === u.current && u.step === "download" ? "run" : "";
      li.querySelector(".st").textContent = "";
    });
    const pct = u.step === "download" ? (u.current / u.total) * 80 + 5 : u.step === "parse" ? 88 : 95;
    setRing(pct);
    return;
  }
  if (!u.done) return;
  items.forEach((li, i) => {
    const info = lists ? lists[LIST_IDS[i]] : null;
    const ok = info ? info.ok : u.result?.ok;
    li.className = ok ? "ok" : "fail";
    li.querySelector(".st").textContent = ok ? UI.t("list_ok") : UI.t("list_failed");
  });
  const msg = $("dlMsg");
  msg.hidden = false;
  if (u.result?.ok) {
    filterState = "done";
    setRing(100, "ok");
    msg.className = "dl-msg ok";
    msg.textContent = u.result.changed
      ? UI.t("upd_done_new", { n: UI.fmt(u.result.networkCount + u.result.cosmeticCount) })
      : UI.t("upd_done_same");
    $("retry").hidden = true;
  } else {
    filterState = "failed";
    setRing(100, "warn");
    msg.className = "dl-msg warn";
    msg.textContent = UI.t("ob_filters_offline");
    $("retry").hidden = false;
  }
  updateNext();
}

function startFilters() {
  filterState = "running";
  $("dlMsg").hidden = true;
  $("retry").hidden = true;
  setRing(3);
  renderFilterState({ running: true, step: "download", current: 0, total: LIST_NAMES.length });
  updateNext();
  chrome.runtime.sendMessage({ type: "update-now" });
}
$("retry").addEventListener("click", startFilters);

chrome.storage.onChanged.addListener(async (c, area) => {
  if (area === "local" && c.updateState && filterState === "running") {
    const { filterMeta = {} } = await chrome.storage.local.get("filterMeta");
    renderFilterState(c.updateState.newValue || {}, filterMeta.lists);
  }
  if (area === "local" && c.status && step === STEPS - 1) celebrate(false);
  if (area === "sync") renderSites();
});

// ---------- Fertig ----------
const COLORS = ["#8b6cff", "#22d3ee", "#22c55e", "#facc15", "#f472b6", "#c4b8ff"];
async function celebrate(burst = true) {
  const st = await UI.getStatus();
  UI.setLight($("doneLight"), st.level === "black" ? "black" : st.level === "red" ? "red" : st.level);
  if (!burst) return;
  const box = $("confetti");
  box.innerHTML = "";
  for (let i = 0; i < 36; i++) {
    const p = document.createElement("i");
    const angle = (Math.PI * 2 * i) / 36 + Math.random() * 0.3;
    const dist = 90 + Math.random() * 110;
    p.style.setProperty("--x", Math.cos(angle) * dist + "px");
    p.style.setProperty("--y", Math.sin(angle) * dist + "px");
    p.style.setProperty("--r", (Math.random() * 720 - 360) + "deg");
    p.style.setProperty("--delay", Math.random() * 0.15 + "s");
    p.style.background = COLORS[i % COLORS.length];
    box.append(p);
  }
}

(async () => {
  await UI.init();
  UI.onLang(renderLang);
  renderLang();
  renderSites();
  show(0);
})();
