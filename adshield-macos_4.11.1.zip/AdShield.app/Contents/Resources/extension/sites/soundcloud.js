// SoundCloud: gesponserte Tracks im Stream und Werbung in der Seitenleiste
(() => {
  const LABELS = new Set([
    "Promoted", "Gesponsert", "Werbung", "Anzeige", "Advertisement", "Sponsored"
  ]);

  const CONTAINERS = [
    ".soundList__item", ".lazyLoadingList__item", ".sidebarModule",
    ".trackList__item", ".systemPlaylistTrackList__item", "li"
  ].join(",");

  AdShield.site({
    key: "soundcloud",
    css: `
      .sidebarModule.ad, .sc-promoted, [class*="promotedBadge"],
      .soundList__item:has([class*="promoted" i]),
      .soundList__item:has(.sc-ministats-promoted)
      { display: none !important; }
    `,
    scan() {
      for (const label of AdShield.findLabels(LABELS, "span, div, a")) {
        AdShield.hide(label.closest(CONTAINERS));
      }
    }
  });
})();
