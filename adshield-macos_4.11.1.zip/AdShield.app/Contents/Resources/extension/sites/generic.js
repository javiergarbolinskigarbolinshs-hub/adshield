// Alle anderen Webseiten: Ausblende-Regeln aus den Filterlisten anwenden
(() => {
  if (location.protocol !== "http:" && location.protocol !== "https:") return;
  AdShield.site({ key: "other" });
})();
