// Google-Suche: Textanzeigen oben/unten, Shopping-Anzeigen, Seitenleiste
(() => {
  const DIRECT = [
    "#tads", "#tadsb", "#tvcap", "#bottomads", "div[data-text-ad]",
    ".commercial-unit-desktop-top", ".commercial-unit-desktop-rhs",
    ".cu-container", ".pla-unit-container", "[data-pla]"
  ].join(",");

  const CONTAINERS = DIRECT + ",.uEierd,.vdQmEd";

  const LABELS = new Set([
    "Gesponsert", "Gesponserte Ergebnisse", "Gesponserte Produkte",
    "Anzeige", "Anzeigen", "Werbung", "Sponsored", "Sponsored results",
    "Sponsorowane", "Ad", "Ads"
  ]);

  AdShield.site({
    key: "google",
    css: `${DIRECT}{display:none!important}`,
    scan() {
      document.querySelectorAll(DIRECT).forEach(AdShield.hide);
      for (const label of AdShield.findLabels(LABELS, "span, div[role='heading']")) {
        AdShield.hide(label.closest(CONTAINERS));
      }
    }
  });
})();
