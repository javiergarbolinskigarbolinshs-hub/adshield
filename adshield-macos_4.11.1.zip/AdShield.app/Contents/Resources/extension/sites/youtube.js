// YouTube und YouTube Music: Werbebanner ausblenden, Video-/Audio-Werbung
// stummschalten, vorspulen und "Überspringen" automatisch klicken.
(() => {
  const isMusic = location.hostname === "music.youtube.com";

  const CSS = `
    ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer,
    ytd-promoted-sparkles-web-renderer, ytd-promoted-video-renderer,
    ytd-display-ad-renderer, ytd-banner-promo-renderer,
    ytd-statement-banner-renderer, ytd-player-legacy-desktop-watch-ads-renderer,
    ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
    ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
    #masthead-ad, #player-ads, .ytp-ad-overlay-container, .ytp-ad-image-overlay,
    .ytp-featured-product, ytd-mealbar-promo-renderer,
    ytmusic-mealbar-promo-renderer, ytmusic-statement-banner-renderer
    { display: none !important; }
  `;

  const SKIP_BUTTONS = [
    ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern", ".ytp-skip-ad-button",
    ".ytp-ad-skip-button-slot button", ".ytp-ad-skip-button-container button",
    "button.ytp-ad-skip-button-modern", ".videoAdUiSkipButton"
  ].join(",");
  const SKIP_TEXT = /^(skip|überspringen|skip ads?|werbung überspringen|anzeige überspringen)/i;

  // "Überspringen" klicken: erst über bekannte Klassen, dann über den Text im Werbe-Bereich
  function clickSkip(root) {
    let clicked = false;
    root.querySelectorAll(SKIP_BUTTONS).forEach((b) => { b.click(); clicked = true; });
    if (!clicked) {
      root.querySelectorAll(".ytp-ad-module button, .ytp-ad-player-overlay button").forEach((b) => {
        if (SKIP_TEXT.test((b.textContent || b.getAttribute("aria-label") || "").trim())) { b.click(); clicked = true; }
      });
    }
    return clicked;
  }

  // Meldung "Werbeblocker sind auf YouTube nicht erlaubt" wegräumen, Video läuft weiter
  function clearEnforcement(video) {
    const msg = document.querySelector("ytd-enforcement-message-view-model, #error-screen ytd-enforcement-message-view-model");
    if (!msg) return;
    msg.closest("tp-yt-paper-dialog")?.remove();
    msg.remove();
    document.querySelectorAll("tp-yt-iron-overlay-backdrop").forEach((e) => e.remove());
    document.documentElement.style.overflow = "";
    document.body && (document.body.style.overflow = "");
    if (video && video.paused && !video.ended) video.play().catch(() => {});
  }

  let inAd = false;
  let saved = { muted: false, rate: 1 };

  AdShield.site({
    key: isMusic ? "ytmusic" : "youtube",
    css: CSS,
    interval: 100, // Werbung im Player sehr schnell erkennen
    scan() {
      const player = document.querySelector(
        ".html5-video-player.ad-showing, .html5-video-player.ad-interrupting"
      );
      const video = player?.querySelector("video") || document.querySelector("video");

      if (player && video) {
        if (!inAd) {
          inAd = true;
          saved = { muted: video.muted, rate: video.playbackRate > 4 ? 1 : video.playbackRate };
          AdShield.report(1);
        }
        video.muted = true;
        video.playbackRate = 16;
        if (Number.isFinite(video.duration) && video.duration > 0) {
          video.currentTime = Math.max(video.currentTime, video.duration - 0.05);
        }
        if (video.paused && !video.ended) video.play().catch(() => {});
        // Überspringen-Knopf sofort drücken, sobald er da ist
        clickSkip(document);
      } else if (inAd) {
        // Werbung vorbei: Lautstärke und Tempo zurücksetzen
        inAd = false;
        if (video) {
          video.muted = saved.muted;
          video.playbackRate = saved.rate;
        }
      }

      clearEnforcement(video);

      // Feed-Anzeigen mitzählen
      document.querySelectorAll("ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, #masthead-ad")
        .forEach(AdShield.hide);
    }
  });
})();
