const DEFAULTS = { enabled: true, google: true, youtube: true, ytmusic: true, soundcloud: true, other: true };
const KEYS = ["google", "youtube", "ytmusic", "soundcloud", "other"];
const $ = (id) => document.getElementById(id);

function greet() {
  const h = new Date().getHours();
  $("greeting").textContent = UI.t(h < 11 ? "greet_morning" : h < 18 ? "greet_day" : "greet_evening");
}

async function renderSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $("enabled").checked = s.enabled;
  $("app").classList.toggle("off", !s.enabled);
  let on = 0;
  document.querySelectorAll("[data-key]").forEach((input) => {
    const v = s[input.dataset.key];
    input.checked = v;
    input.closest(".card").classList.toggle("disabled", !v);
    if (v && s.enabled) on++;
  });
  $("active").textContent = `${on} / ${KEYS.length}`;
}

async function renderStats() {
  const today = new Date().toISOString().slice(0, 10);
  const st = await chrome.storage.local.get({ total: 0, today: 0, day: today, sites: {} });
  $("total").textContent = UI.fmt(st.total);
  $("today").textContent = UI.fmt(st.day === today ? st.today : 0);
  document.querySelectorAll("[data-count]").forEach((el) => {
    el.textContent = UI.t("blocked_n", { n: UI.fmt(st.sites[el.dataset.count] || 0) });
  });
}

async function renderStatus() {
  const status = await UI.getStatus();
  UI.setLight($("light"), status.level);
  $("statusText").textContent = UI.t("status_" + status.level);
  const n = $("notice");
  if (status.level === "green" || !status.issues.length) { n.hidden = true; return; }
  n.hidden = false;
  n.dataset.level = status.level;
  UI.setLight($("noticeLight"), status.level);
  const first = status.issues.find((i) => i.sev === "error") || status.issues[0];
  const more = status.issues.length > 1 ? `  (+${status.issues.length - 1})` : "";
  $("noticeText").textContent = UI.issueText(first) + more;
}

const renderAll = () => { greet(); renderSettings(); renderStats(); renderStatus(); };

$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
document.querySelectorAll("[data-key]").forEach((input) => {
  input.addEventListener("change", () => chrome.storage.sync.set({ [input.dataset.key]: input.checked }));
});

document.querySelectorAll(".card").forEach((card) => {
  card.tabIndex = 0;
  const open = () => { if (card.dataset.url) location.href = card.dataset.url; };
  card.addEventListener("click", (e) => { if (!e.target.closest("[data-stop]")) open(); });
  card.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target === card) open(); });
});

$("search").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = $("q").value.trim();
  if (!q) return;
  const looksLikeUrl = /^(https?:\/\/)?[\w-]+(\.[\w-]+)+(\/\S*)?$/i.test(q) && !q.includes(" ");
  location.href = looksLikeUrl
    ? (q.startsWith("http") ? q : "https://" + q)
    : "https://www.google.com/search?q=" + encodeURIComponent(q);
});

$("reset").addEventListener("click", () => chrome.storage.local.set({ total: 0, today: 0, sites: {} }));

chrome.storage.onChanged.addListener((c, area) => {
  if (area === "local" && c.onboarded?.newValue === false) { location.replace("onboarding.html"); return; }
  if (area === "sync") renderSettings();
  if (area === "local") { if (c.status) renderStatus(); else renderStats(); }
});

(async () => {
  // Beim allerersten Start: Tutorial
  const { onboarded = true } = await chrome.storage.local.get("onboarded");
  if (onboarded === false) { location.replace("onboarding.html"); return; }
  await UI.init();
  UI.onLang(renderAll);
  renderAll();
  $("q").focus();
})();
