// Gemeinsame Logik für alle Seiten: Einstellungen lesen, Werbung
// ausblenden, Zähler melden. Wird vor dem jeweiligen Seiten-Skript geladen.
const AdShield = (() => {
  const DEFAULTS = { enabled: true, google: true, youtube: true, ytmusic: true, soundcloud: true, other: true };
  const HIDDEN_ATTR = "data-adshield";

  // Treffer sammeln und gebündelt an den Hintergrund melden
  let siteKey = null;
  let pending = 0;
  let flushTimer = null;
  function report(n = 1) {
    pending += n;
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
      const count = pending;
      pending = 0;
      flushTimer = null;
      try { chrome.runtime.sendMessage({ type: "blocked", count, site: siteKey }); } catch (e) { /* Erweiterung neu geladen */ }
    }, 800);
  }

  // Element ausblenden; zählt nur beim ersten Mal
  function hide(el) {
    if (!el || el.getAttribute(HIDDEN_ATTR) === "hidden") return false;
    el.setAttribute(HIDDEN_ATTR, "hidden");
    report(1);
    return true;
  }

  // Blattelemente finden, deren Text genau einem Werbe-Label entspricht
  function findLabels(labels, selector = "span, div, p") {
    const out = [];
    for (const el of document.querySelectorAll(selector)) {
      if (el.childElementCount === 0 && labels.has(el.textContent.trim())) out.push(el);
    }
    return out;
  }

  function site({ key, css = "", scan, interval = 0 }) {
    siteKey = key;
    let active = false;
    let styleEl = null;
    let observer = null;
    let timer = null;
    let scheduled = false;

    // Ausblende-Regeln aus den Filter-Updates
    let cosmeticEl = null;
    let cosmeticSelector = "";
    const counted = new WeakSet();

    // Ungültige Selektoren aussortieren (in Blöcken, damit es schnell geht)
    function validSelectors(list) {
      const sheet = new CSSStyleSheet();
      const ok = (sel) => { try { sheet.insertRule(`${sel}{}`); sheet.deleteRule(0); return true; } catch (e) { return false; } };
      const out = [];
      for (let i = 0; i < list.length; i += 100) {
        const chunk = list.slice(i, i + 100);
        if (ok(chunk.join(","))) out.push(...chunk);
        else for (const sel of chunk) if (ok(sel)) out.push(sel);
      }
      return out;
    }

    function loadCosmetic() {
      const use = (list) => {
        const valid = validSelectors(list || []);
        cosmeticSelector = valid.join(",");
        if (!active) return;
        if (!cosmeticEl) {
          cosmeticEl = document.createElement("style");
          cosmeticEl.id = "adshield-filters";
          (document.head || document.documentElement).appendChild(cosmeticEl);
        }
        cosmeticEl.textContent = valid.length ? `${cosmeticSelector}{display:none!important}` : "";
        schedule();
      };
      if (key === "other") {
        // Alle anderen Webseiten: passende Regeln vom Hintergrund holen
        try {
          chrome.runtime.sendMessage({ type: "get-cosmetic", host: location.hostname }, (res) => {
            void chrome.runtime.lastError;
            use(res?.selectors);
          });
        } catch (e) { /* Erweiterung neu geladen */ }
      } else {
        chrome.storage.local.get({ cosmetic: {} }, ({ cosmetic }) => use(cosmetic[key]));
      }
    }

    let lastCount = 0;
    function countCosmetic() {
      if (!cosmeticSelector) return;
      // Bei sehr vielen Regeln (alle Webseiten) seltener zählen
      if (key === "other" && Date.now() - lastCount < 2000) return;
      lastCount = Date.now();
      for (const el of document.querySelectorAll(cosmeticSelector)) {
        if (!counted.has(el) && el.getAttribute(HIDDEN_ATTR) !== "hidden") {
          counted.add(el);
          report(1);
        }
      }
    }

    const run = () => {
      scheduled = false;
      if (!active) return;
      try { scan?.(); } catch (e) { /* Seite hat sich geändert – nächster Durchlauf */ }
      try { countCosmetic(); } catch (e) { /* ungültiger Selektor */ }
    };
    // setTimeout statt requestAnimationFrame: läuft auch in Hintergrund-Tabs (Musik!)
    const schedule = () => {
      if (scheduled) return;
      scheduled = true;
      setTimeout(run, 120);
    };

    function start() {
      if (active) return;
      active = true;
      styleEl = document.createElement("style");
      styleEl.id = "adshield-style";
      styleEl.textContent = `[${HIDDEN_ATTR}="hidden"]{display:none!important}\n${css}`;
      (document.head || document.documentElement).appendChild(styleEl);
      observer = new MutationObserver(schedule);
      observer.observe(document.documentElement, { childList: true, subtree: true });
      if (interval) timer = setInterval(run, interval);
      loadCosmetic();
      schedule();
    }

    function stop() {
      if (!active) return;
      active = false;
      styleEl?.remove();
      cosmeticEl?.remove();
      observer?.disconnect();
      if (timer) clearInterval(timer);
      styleEl = cosmeticEl = observer = timer = null;
    }

    function apply() {
      chrome.storage.local.get({ devFlags: {} }, ({ devFlags }) => chrome.storage.sync.get(DEFAULTS, (s) => (s.enabled && s[key] && !devFlags.noContent ? start() : stop())));
    }

    apply();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "sync") apply();
      if (area === "local" && (changes.cosmetic || changes.cosmeticAll)) loadCosmetic();
    });
    return { isActive: () => active };
  }

  return { site, hide, report, findLabels };
})();
