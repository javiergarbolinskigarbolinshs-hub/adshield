const DEFAULTS = { enabled: true, google: true, youtube: true, ytmusic: true, soundcloud: true, other: true, autoUpdate: true };
const KEYS = ["google", "youtube", "ytmusic", "soundcloud", "other"];
const LIST_NAMES = { easylist: "EasyList", easylistgermany: "EasyList Germany", ublock: "uBlock Filters", quickfixes: "uBlock Quick Fixes" };
const $ = (id) => document.getElementById(id);

// ---------- Status ----------
const FIXES = {
  paused: { label: "fix_enable", run: () => chrome.storage.sync.set({ enabled: true }) },
  sites_off: { label: "fix_sites", run: () => chrome.storage.sync.set({ google: true, youtube: true, ytmusic: true, soundcloud: true, other: true }) },
  never_updated: { label: "fix_update", run: () => startUpdate() },
  outdated: { label: "fix_update", run: () => startUpdate() },
  update_failed: { label: "fix_retry", run: () => startUpdate() },
  lists_partial: { label: "fix_retry", run: () => startUpdate() },
  update_crashed: { label: "fix_retry", run: () => startUpdate() },
  auto_off: { label: "fix_auto", run: () => chrome.storage.sync.set({ autoUpdate: true }) },
  rules_error: { label: "fix_retry", run: () => chrome.storage.sync.set({ _retry: Date.now() }) }
};

async function renderStatus() {
  const st = await UI.getStatus();
  UI.setLight($("bigLight"), st.level);
  $("status").dataset.level = st.level;
  $("statusTitle").textContent = UI.t("status_" + st.level);
  $("statusSub").textContent = UI.t("status_" + st.level + "_sub");

  const ul = $("issues");
  ul.innerHTML = "";
  if (!st.issues.length) {
    const li = document.createElement("li");
    li.className = "ok";
    li.innerHTML = `<span class="light" data-level="green"></span><span class="txt"></span>`;
    li.querySelector(".txt").textContent = UI.t("no_issues");
    ul.append(li);
    return;
  }
  for (const issue of st.issues) {
    const li = document.createElement("li");
    const level = issue.sev === "error" ? "black" : issue.sev === "off" ? "red" : "yellow";
    li.innerHTML = `<span class="light" data-level="${level}"></span><span class="txt"></span>`;
    li.querySelector(".txt").textContent = UI.issueText(issue);
    const fix = FIXES[issue.code];
    if (fix) {
      const b = document.createElement("button");
      b.className = "btn small";
      b.textContent = UI.t(fix.label);
      b.addEventListener("click", () => fix.run());
      li.append(b);
    }
    ul.append(li);
  }
}

// ---------- Updates ----------
async function renderUpdates() {
  const { filterMeta: m = {}, updateState: u = {}, dynamicActive = 0 } =
    await chrome.storage.local.get(["filterMeta", "updateState", "dynamicActive"]);
  $("lastSuccess").textContent = UI.ago(m.lastSuccess);
  $("lastCheck").textContent = UI.ago(m.lastCheck);
  $("netRules").textContent = `${UI.fmt(dynamicActive || m.networkCount || 0)}  ${UI.t("set_builtin")}`;
  $("cosRules").textContent = UI.fmt(m.cosmeticCount || 0);

  const ul = $("lists");
  ul.innerHTML = "";
  for (const [id, name] of Object.entries(LIST_NAMES)) {
    const info = m.lists?.[id];
    const li = document.createElement("li");
    const tag = !info ? ["wait", "list_waiting"] : info.ok ? ["ok", "list_ok"] : ["fail", "list_failed"];
    li.innerHTML = `<span><span class="nm"></span><span class="tag ${tag[0]}"></span></span><span class="meta"></span>`;
    li.querySelector(".nm").textContent = name;
    li.querySelector(".tag").textContent = UI.t(tag[1]);
    if (info?.ok && (info.network != null || info.cosmetic != null)) {
      li.querySelector(".meta").textContent = `${UI.fmt(info.network || 0)} / ${UI.fmt(info.cosmetic || 0)}`;
    }
    ul.append(li);
  }
  renderProgress(u);
}

function renderProgress(u) {
  const bar = $("progress"), msg = $("updMsg"), btn = $("checkBtn");
  if (u.running) {
    btn.disabled = true;
    btn.classList.add("busy");
    bar.hidden = false;
    msg.hidden = false;
    msg.dataset.kind = "";
    const pct = Math.round(((u.current || 0) + (u.step === "download" ? 0.5 : 0)) / (u.total || 1) * 90) + (u.step === "apply" ? 8 : 0);
    bar.querySelector("i").style.width = Math.min(pct, 98) + "%";
    msg.textContent = u.step === "download" ? UI.t("upd_download", { name: u.name })
      : u.step === "parse" ? UI.t("upd_parse") : UI.t("upd_apply");
    return;
  }
  btn.disabled = false;
  btn.classList.remove("busy");
  if (u.done && u.result && Date.now() - (u.at || 0) < 120000) {
    bar.hidden = false;
    bar.querySelector("i").style.width = "100%";
    msg.hidden = false;
    const r = u.result;
    if (r.ok) {
      msg.dataset.kind = "ok";
      msg.textContent = r.changed ? UI.t("upd_done_new", { n: UI.fmt(r.networkCount + r.cosmeticCount) }) : UI.t("upd_done_same");
    } else {
      msg.dataset.kind = r.error === "network" ? "warn" : "err";
      msg.textContent = UI.t(r.error === "network" ? "upd_failed" : "upd_crashed");
    }
  } else {
    bar.hidden = true;
    msg.hidden = true;
  }
}

function startUpdate() {
  $("updates").scrollIntoView({ behavior: "smooth", block: "center" });
  renderProgress({ running: true, step: "download", name: "…", current: 0, total: 4 });
  chrome.runtime.sendMessage({ type: "update-now" });
}

// ---------- Einstellungen ----------
async function renderSettings() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  $("enabled").checked = s.enabled;
  $("autoUpdate").checked = s.autoUpdate;
  $("sites").classList.toggle("off", !s.enabled);
  document.querySelectorAll("[data-key]").forEach((i) => { i.checked = s[i.dataset.key]; });
  document.querySelectorAll("#langSeg button").forEach((b) => {
    b.setAttribute("aria-pressed", String(b.dataset.lang === UI.getLang()));
  });
}

$("enabled").addEventListener("change", (e) => chrome.storage.sync.set({ enabled: e.target.checked }));
$("autoUpdate").addEventListener("change", (e) => chrome.storage.sync.set({ autoUpdate: e.target.checked }));
document.querySelectorAll("[data-key]").forEach((i) => {
  i.addEventListener("change", () => chrome.storage.sync.set({ [i.dataset.key]: i.checked }));
});
document.querySelectorAll("#langSeg button").forEach((b) => b.addEventListener("click", () => UI.setLang(b.dataset.lang)));
$("checkBtn").addEventListener("click", startUpdate);
$("reset").addEventListener("click", () => chrome.storage.local.set({ total: 0, today: 0, sites: {} }));

chrome.storage.onChanged.addListener((c, area) => {
  if (area === "sync") renderSettings();
  if (area === "local") {
    if (c.status) renderStatus();
    if (c.filterMeta || c.updateState || c.dynamicActive) renderUpdates();
  }
});

(async () => {
  await UI.init();
  $("version").textContent = chrome.runtime.getManifest().version;
  UI.onLang(() => { renderSettings(); renderStatus(); renderUpdates(); });
  renderSettings();
  renderStatus();
  renderUpdates();
  setInterval(renderUpdates, 30000); // "vor X Min." aktuell halten
  if (location.hash) {
    const el = document.querySelector(location.hash);
    if (el) { el.scrollIntoView({ block: "start" }); el.classList.add("flash"); }
  }
})();
