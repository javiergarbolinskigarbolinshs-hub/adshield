// AdShield Tarnmodus: Seiten sollen nicht merken, dass ein Werbeblocker läuft.
// Läuft direkt in der Seite (world: MAIN), vor allen Seiten-Skripten.
(() => {
  "use strict";
  if (window.__adshieldStealth) return;
  Object.defineProperty(window, "__adshieldStealth", { value: true });

  // Typische "Köder"-Elemente, mit denen Seiten Werbeblocker testen
  const BAIT = /(^|[\s_-])(ad|ads|adsbox|ad-box|adbox|adbanner|ad-banner|banner[_-]?ad|adsbygoogle|ad-placement|ad-slot|adslot|advert|advertisement|textad|text-ad|pub_300x250|sponsor|sponsored|doubleclick)([\s_-]|$)/i;
  const isBait = (el) => {
    try {
      if (!el || el.nodeType !== 1) return false;
      if (el.tagName === "IFRAME" || el.tagName === "INS" && el.classList.contains("adsbygoogle") && el.children.length) return false;
      // Nur kleine, leere Köder – keine echten Inhalte
      if (el.children.length > 0 || (el.textContent || "").length > 40) return false;
      return BAIT.test(el.className && el.className.baseVal === undefined ? String(el.className) : "") || BAIT.test(el.id || "");
    } catch { return false; }
  };

  const fake = (proto, prop, value) => {
    const d = Object.getOwnPropertyDescriptor(proto, prop);
    if (!d || !d.get) return;
    const getter = function () {
      const real = d.get.call(this);
      return real === 0 && isBait(this) ? value : real;
    };
    Object.defineProperty(getter, "name", { value: d.get.name });
    Object.defineProperty(proto, prop, { ...d, get: getter });
  };
  fake(HTMLElement.prototype, "offsetHeight", 1);
  fake(HTMLElement.prototype, "offsetWidth", 1);
  fake(Element.prototype, "clientHeight", 1);
  fake(Element.prototype, "clientWidth", 1);

  // getComputedStyle: Köder sehen "sichtbar" aus
  const origGCS = window.getComputedStyle;
  const patchedGCS = function (el, pseudo) {
    const cs = origGCS.call(this, el, pseudo);
    if (!isBait(el)) return cs;
    return new Proxy(cs, {
      get(t, k) {
        if (k === "display") return "block";
        if (k === "visibility") return "visible";
        if (k === "opacity") return "1";
        if (k === "height" && t.height === "0px") return "1px";
        if (k === "getPropertyValue") {
          return (n) => n === "display" ? "block" : n === "visibility" ? "visible" : t.getPropertyValue(n);
        }
        const v = Reflect.get(t, k, t);
        return typeof v === "function" ? v.bind(t) : v;
      }
    });
  };
  Object.defineProperty(patchedGCS, "name", { value: "getComputedStyle" });
  window.getComputedStyle = patchedGCS;

  // Häufig geprüfte Werbe-Variablen vortäuschen
  try {
    if (!window.adsbygoogle) window.adsbygoogle = { loaded: true, push() {} };
    if (!window.canRunAds) window.canRunAds = true;
    if (!window.google_ad_client) window.google_ad_client = "ca-pub-0";
  } catch {}

  // Funktions-Namen normal aussehen lassen
  const nativeToString = Function.prototype.toString;
  const patched = new Map([[patchedGCS, "function getComputedStyle() { [native code] }"]]);
  Function.prototype.toString = new Proxy(nativeToString, {
    apply(t, self, args) { return patched.get(self) || Reflect.apply(t, self, args); }
  });
})();
