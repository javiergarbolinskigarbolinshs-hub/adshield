(function(){var n=function(){return this};var s={addService:n,setTargeting:n,defineSizeMapping:n,setCollapseEmptyDiv:n,getSlotElementId:function(){return""},set:n,get:function(){return null}};
window.googletag=window.googletag||{};var g=window.googletag;g.cmd=g.cmd||[];g.apiReady=true;g.pubadsReady=true;
var ps={enableSingleRequest:n,enableAsyncRendering:n,enableLazyLoad:n,collapseEmptyDivs:n,disableInitialLoad:n,refresh:n,setTargeting:n,addEventListener:n,setPrivacySettings:n,getSlots:function(){return[]},clear:n,setCentering:n};
g.pubads=function(){return ps};g.defineSlot=function(){return s};g.defineOutOfPageSlot=function(){return s};g.enableServices=n;g.display=n;g.destroySlots=n;g.companionAds=function(){return ps};g.sizeMapping=function(){return{addSize:n,build:function(){return[]}}};
g.cmd.push=function(f){try{typeof f==="function"&&f()}catch(e){}return 0};
(g.cmd.splice(0)||[]).forEach(function(f){try{f()}catch(e){}});})();
