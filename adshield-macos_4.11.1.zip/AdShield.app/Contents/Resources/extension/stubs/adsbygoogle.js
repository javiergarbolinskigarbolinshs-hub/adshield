(function(){var a=window.adsbygoogle=window.adsbygoogle||[];a.loaded=true;if(!a.push||a.push===Array.prototype.push){a.push=function(){return 0}};window.google_ad_status=1;})();
