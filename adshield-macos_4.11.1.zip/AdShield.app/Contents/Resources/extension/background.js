// AdShield Hintergrund:
// - eingebaute Regelsätze an/aus
// - Filterlisten-Updates (täglich + auf Knopfdruck) -> dynamische Regeln
// - Status-Ampel (green / yellow / red / black) + Icon
// - Zähler, Lesezeichen, Tutorial beim ersten Start
importScripts("filters.js");

const DEFAULTS = {
  enabled: true, google: true, youtube: true, ytmusic: true, soundcloud: true, other: true,
  autoUpdate: true, lang: ""
};
const SITE_KEYS = ["google", "youtube", "ytmusic", "soundcloud"];
const AREA_KEYS = [...SITE_KEYS, "other"]; // "other" = alle anderen Webseiten
const HOME = chrome.runtime.getURL("home.html");
const DAY = 24 * 60 * 60 * 1000;
const ALARM = "filter-update";

const RULESETS = {
  google: (s) => s.google || s.other,
  youtube: (s) => s.youtube || s.ytmusic,
  soundcloud: (s) => s.soundcloud,
  stubs: (s) => s.other || s.google || s.youtube || s.soundcloud
};

const getSettings = () => chrome.storage.sync.get(DEFAULTS);

// Läuft die Erweiterung im normalen Google Chrome (statt im AdShield-Chromium)?
const IS_GOOGLE_CHROME = (navigator.userAgentData?.brands || []).some((b) => b.brand === "Google Chrome");

// ---------- eingebaute Regeln ----------
const BUILTIN_ALLOW = ["imasdk.googleapis.com"];
const getFlags = async () => (await chrome.storage.local.get({ devFlags: {} })).devFlags;

async function syncStealth() {
  try {
    const f = await getFlags();
    const reg = await chrome.scripting.getRegisteredContentScripts({ ids: ["stealth"] });
    if (!f.noStealth && !reg.length) {
      await chrome.scripting.registerContentScripts([{ id: "stealth", matches: ["http://*/*", "https://*/*"], js: ["stealth.js"], runAt: "document_start", world: "MAIN", persistAcrossSessions: true }]);
    } else if (f.noStealth && reg.length) {
      await chrome.scripting.unregisterContentScripts({ ids: ["stealth"] });
    }
  } catch (e) { /* ignorieren */ }
}

async function syncStaticRules(s) {
  const flags = await getFlags();
  const enableRulesetIds = [], disableRulesetIds = [];
  for (const [id, isOn] of Object.entries(RULESETS)) {
    (s.enabled && isOn(s) && !(id === "stubs" && flags.noStubs) && !flags.noStatic ? enableRulesetIds : disableRulesetIds).push(id);
  }
  await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds, disableRulesetIds });
}

// ---------- dynamische Regeln aus Filterlisten ----------
async function addRulesSafely(rules, skipped) {
  if (!rules.length) return;
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ addRules: rules });
  } catch (e) {
    if (rules.length === 1) { skipped.push(rules[0]); return; }
    const mid = Math.ceil(rules.length / 2);
    await addRulesSafely(rules.slice(0, mid), skipped);
    await addRulesSafely(rules.slice(mid), skipped);
  }
}

async function applyDynamicRules(s) {
  const existing = await chrome.declarativeNetRequest.getDynamicRules();
  if (existing.length) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: existing.map((r) => r.id) });
  }
  if (!s.enabled) return { added: 0, skipped: 0 };

  const devFlags = await getFlags();
  const { filterRules: storedRules = [] } = await chrome.storage.local.get("filterRules");
  const filterRules = devFlags.noLists ? [] : storedRules;
  const limit = Math.min(
    MAX_NETWORK_RULES,
    (chrome.declarativeNetRequest.MAX_NUMBER_OF_DYNAMIC_RULES || 5000) - 100
  );
  const offDomains = SITE_KEYS.filter((k) => !s[k]).flatMap((k) => SITE_DOMAINS[k]);
  const onDomains = SITE_KEYS.filter((k) => s[k]).flatMap((k) => SITE_DOMAINS[k]);

  const rules = [];
  for (const r of filterRules.slice(0, limit)) {
    const condition = { ...r.condition };
    if (r.action === "block") {
      if (offDomains.length) {
        condition.excludedInitiatorDomains = [...new Set([...(condition.excludedInitiatorDomains || []), ...offDomains])];
      }
      // "Alle anderen Webseiten" aus: allgemeine Regeln nur auf unseren Seiten
      if (!s.other && !condition.initiatorDomains) {
        if (!onDomains.length) continue;
        condition.initiatorDomains = onDomains;
      }
    }
    rules.push({ id: rules.length + 1, priority: r.priority, action: { type: r.action }, condition });
  }
  // Vom Nutzer erlaubte Adressen (Diagnose im Popup) – haben immer Vorrang
  const { allowHosts = [] } = await chrome.storage.local.get("allowHosts");
  // Immer erlaubt: Seiten prüfen damit heimlich, ob ein Werbeblocker läuft (z. B. South Park: imasdk.googleapis.com)
  for (const h of [...new Set([...BUILTIN_ALLOW, ...allowHosts])]) {
    rules.push({ id: rules.length + 1, priority: 100, action: { type: "allow" }, condition: { requestDomains: [h] } });
  }

  const skipped = [];
  await addRulesSafely(rules, skipped);
  return { added: rules.length - skipped.length, skipped: skipped.length };
}

// Alles anwenden, Fehler merken
let applyQueue = Promise.resolve();
function applyAll() {
  applyQueue = applyQueue.then(async () => {
    const s = await getSettings();
    let rulesError = null;
    try {
      await syncStealth();
      await syncStaticRules(s);
      const res = await applyDynamicRules(s);
      await chrome.storage.local.set({ dynamicActive: res.added });
    } catch (e) {
      rulesError = String(e?.message || e);
    }
    await chrome.storage.local.set({ rulesError });
    await scheduleUpdates(s);
    await computeStatus();
  }).catch(() => {});
  return applyQueue;
}

// ---------- Updates ----------
async function setUpdateState(state) {
  await chrome.storage.local.set({ updateState: { ...state, at: Date.now() } });
}

async function fetchList(list) {
  let lastErr;
  for (const url of list.urls) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 30000);
      const res = await fetch(url, { cache: "no-store", signal: ctrl.signal });
      clearTimeout(timer);
      if (!res.ok) throw new Error("HTTP " + res.status);
      const text = await res.text();
      if (text.length < 50) throw new Error("leer");
      return text;
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("network");
}

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

let running = null;
function runUpdate(trigger = "manual") {
  if (running) return running;
  running = (async () => {
    const { filterMeta: prev = {} } = await chrome.storage.local.get("filterMeta");
    const meta = { ...prev, lastCheck: Date.now(), trigger };
    let result;
    try {
      const texts = {};
      const lists = {};
      for (let i = 0; i < FILTER_LISTS.length; i++) {
        const list = FILTER_LISTS[i];
        await setUpdateState({ running: true, step: "download", name: list.name, current: i, total: FILTER_LISTS.length });
        try {
          texts[list.id] = await fetchList(list);
          lists[list.id] = { ok: true, size: texts[list.id].length };
        } catch (e) {
          lists[list.id] = { ok: false, error: String(e?.message || e) };
        }
      }
      if (!Object.keys(texts).length) {
        const err = new Error("network");
        err.lists = lists;
        throw err;
      }

      await setUpdateState({ running: true, step: "parse", current: FILTER_LISTS.length, total: FILTER_LISTS.length });
      const hash = await sha256("v" + PARSER_VERSION + "\n" + Object.keys(texts).sort().map((k) => texts[k]).join("\n"));
      const changed = hash !== prev.hash;
      let parsed = null;
      if (changed) {
        try {
          parsed = parseFilterLists(texts);
        } catch (e) {
          const err = new Error("internal");
          err.detail = String(e?.message || e);
          throw err;
        }
        for (const [id, st] of Object.entries(parsed.perList)) Object.assign(lists[id], st);
        await setUpdateState({ running: true, step: "apply", current: FILTER_LISTS.length, total: FILTER_LISTS.length });
        await chrome.storage.local.set({ filterRules: parsed.network, cosmetic: parsed.cosmetic, cosmeticAll: parsed.cosmeticAll });
        cosmeticCache = parsed.cosmeticAll;
      } else {
        for (const id of Object.keys(lists)) if (prev.lists?.[id]) lists[id] = { ...prev.lists[id], ...lists[id] };
      }

      Object.assign(meta, {
        hash,
        lastSuccess: Date.now(),
        lastError: null,
        errorDetail: null,
        lists,
        partial: Object.values(lists).some((l) => !l.ok),
        networkCount: parsed ? parsed.networkCount : prev.networkCount || 0,
        cosmeticCount: parsed ? parsed.cosmeticCount : prev.cosmeticCount || 0
      });
      await chrome.storage.local.set({ filterMeta: meta });
      if (changed) await applyAll();
      result = { ok: true, changed, networkCount: meta.networkCount, cosmeticCount: meta.cosmeticCount };
    } catch (e) {
      const kind = e?.message === "network" ? "network" : "internal";
      Object.assign(meta, { lastError: kind, errorDetail: e?.detail || String(e?.message || e) });
      if (e?.lists) meta.lists = e.lists;
      await chrome.storage.local.set({ filterMeta: meta });
      result = { ok: false, error: kind };
    } finally {
      await setUpdateState({ running: false, done: true, result });
      await computeStatus();
      running = null;
    }
    return result;
  })();
  return running;
}

async function scheduleUpdates(s) {
  const alarm = await chrome.alarms.get(ALARM);
  if (s.autoUpdate && !alarm) {
    await chrome.alarms.create(ALARM, { delayInMinutes: 1, periodInMinutes: 24 * 60 });
  } else if (!s.autoUpdate && alarm) {
    await chrome.alarms.clear(ALARM);
  }
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== ALARM) return;
  const s = await getSettings();
  const { filterMeta = {} } = await chrome.storage.local.get("filterMeta");
  if (s.autoUpdate && (!filterMeta.lastSuccess || Date.now() - filterMeta.lastSuccess > DAY - 60000)) {
    runUpdate("auto");
  }
});

// Ausblende-Regeln für alle Webseiten (im Speicher zwischengespeichert)
let cosmeticCache = null;
async function getCosmeticAll() {
  if (!cosmeticCache) {
    const { cosmeticAll = null } = await chrome.storage.local.get("cosmeticAll");
    cosmeticCache = cosmeticAll || { generic: [], byDomain: {}, exceptByDomain: {} };
  }
  return cosmeticCache;
}

// ---------- Status-Ampel ----------
async function computeStatus() {
  const s = await getSettings();
  const { filterMeta: m = {}, rulesError = null, onboarded = false } =
    await chrome.storage.local.get(["filterMeta", "rulesError", "onboarded"]);
  const issues = [];
  let level;

  if (!s.enabled) {
    level = "red";
    issues.push({ code: "paused", sev: "off" });
  } else {
    if (rulesError) issues.push({ code: "rules_error", sev: "error" });
    if (m.lastError === "internal") issues.push({ code: "update_crashed", sev: "error" });
    const off = AREA_KEYS.filter((k) => !s[k]).length;
    if (off) issues.push({ code: "sites_off", sev: "warn", n: off });
    if (!m.lastSuccess) {
      if (onboarded) issues.push({ code: "never_updated", sev: "warn" });
    } else if (Date.now() - m.lastSuccess > 7 * DAY) {
      issues.push({ code: "outdated", sev: "warn", n: Math.floor((Date.now() - m.lastSuccess) / DAY) });
    }
    if (m.lastError === "network") issues.push({ code: "update_failed", sev: "warn" });
    else if (m.partial) issues.push({ code: "lists_partial", sev: "warn" });
    if (!s.autoUpdate) issues.push({ code: "auto_off", sev: "warn" });

    level = issues.some((i) => i.sev === "error") ? "black" : issues.length ? "yellow" : "green";
  }

  await chrome.storage.local.set({ status: { level, issues, at: Date.now() } });
  try {
    await chrome.action.setIcon({
      path: { 16: `icons/status-${level}-16.png`, 32: `icons/status-${level}-32.png` }
    });
    await chrome.action.setBadgeBackgroundColor({
      color: { green: "#16a34a", yellow: "#ca8a04", red: "#dc2626", black: "#111111" }[level]
    });
  } catch (e) { /* Icon nicht wichtig */ }
}

// ---------- Lesezeichen (nur in der App) ----------
const BOOKMARKS = [
  { title: "AdShield", url: HOME },
  { title: "Google", url: "https://www.google.com/" },
  { title: "YouTube", url: "https://www.youtube.com/" },
  { title: "YouTube Music", url: "https://music.youtube.com/" },
  { title: "SoundCloud", url: "https://soundcloud.com/" }
];

async function setupBookmarks() {
  try {
    const [tree] = await chrome.bookmarks.getTree();
    const bar = tree.children.find((n) => n.id === "1") || tree.children[0];
    const existing = new Set((bar.children || []).map((b) => b.url));
    let index = 0;
    for (const b of BOOKMARKS) {
      if (!existing.has(b.url)) await chrome.bookmarks.create({ parentId: bar.id, index, ...b });
      index++;
    }
  } catch (e) { /* Lesezeichen nicht verfügbar */ }
}

// ---------- Ereignisse ----------
chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install" || details.reason === "update") {
    // Chromium meldet per --load-extension geladene Erweiterungen bei jedem
    // Start als "install" – Tutorial nur, wenn es noch nie gezeigt wurde.
    const { onboarded } = await chrome.storage.local.get("onboarded");
    const firstTime = onboarded === undefined;
    if (firstTime) await chrome.storage.local.set({ onboarded: false });
    const { lang } = await chrome.storage.sync.get({ lang: "" });
    if (!lang) {
      const ui = (chrome.i18n.getUILanguage() || "de").toLowerCase();
      await chrome.storage.sync.set({ lang: ui.startsWith("de") ? "de" : "en" });
    }
    if (IS_GOOGLE_CHROME) {
      // Im normalen Google Chrome: keine Lesezeichen anlegen, Tutorial direkt zeigen
      if (firstTime) chrome.tabs.create({ url: chrome.runtime.getURL("onboarding.html") });
    } else {
      setupBookmarks(); // nur im eigenen AdShield-Fenster (Chromium)
    }
  }
  await applyAll();
  // Nach einem App-Update die Filter neu verarbeiten (neue Funktionen)
  if (details.reason === "update") {
    const { filterMeta = {} } = await chrome.storage.local.get("filterMeta");
    if (filterMeta.lastSuccess) runUpdate("auto");
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await applyAll();
  const s = await getSettings();
  const { filterMeta = {} } = await chrome.storage.local.get("filterMeta");
  if (s.autoUpdate && filterMeta.lastSuccess && Date.now() - filterMeta.lastSuccess > DAY) runUpdate("auto");
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "sync") {
    const keys = Object.keys(changes);
    if (keys.length === 1 && keys[0] === "lang") return;
    applyAll();
  }
  if (area === "local" && changes.onboarded) computeStatus();
});

// ---------- Zähler ----------
const today = () => new Date().toISOString().slice(0, 10);
let countQueue = Promise.resolve();
function addBlocked(tabId, site, count) {
  countQueue = countQueue.then(async () => {
    const st = await chrome.storage.local.get({ total: 0, today: 0, day: today(), sites: {} });
    if (st.day !== today()) { st.today = 0; st.day = today(); }
    st.total += count;
    st.today += count;
    if (site) st.sites[site] = (st.sites[site] || 0) + count;
    await chrome.storage.local.set(st);
    if (tabId != null) {
      const key = `tab_${tabId}`;
      const t = (await chrome.storage.session.get({ [key]: 0 }))[key] + count;
      await chrome.storage.session.set({ [key]: t });
      await chrome.action.setBadgeText({ tabId, text: t > 999 ? "999+" : String(t) });
    }
  }).catch(() => {});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "blocked" && msg.count > 0) addBlocked(sender.tab?.id, msg.site, msg.count);
  if (msg?.type === "update-now") { runUpdate("manual").then(sendResponse); return true; }
  if (msg?.type === "get-cosmetic") {
    Promise.all([getCosmeticAll(), getFlags()]).then(([all, f]) => sendResponse({ selectors: f.noCosmetic ? [] : cosmeticForHost(all, msg.host || "") }));
    return true;
  }
  if (msg?.type === "recheck") { computeStatus().then(() => sendResponse(true)); return true; }
});

// ---------- Diagnose: welche Anfragen wurden auf dieser Seite blockiert/ersetzt? ----------
// (nur in entpackten Erweiterungen verfügbar – genau unser Fall)
const netLog = {};
let netTimer = null;
function flushNetLog() {
  netTimer = null;
  const out = {};
  for (const [id, v] of Object.entries(netLog)) out[`net_${id}`] = v;
  chrome.storage.session.set(out).catch(() => {});
}
if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
    const id = info.request.tabId;
    if (id < 0) return;
    let host = "";
    try { host = new URL(info.request.url).hostname; } catch { return; }
    const log = (netLog[id] = netLog[id] || {});
    const e = (log[host] = log[host] || { n: 0, types: [], stub: false, sample: "" });
    e.n++;
    if (!e.types.includes(info.request.type)) e.types.push(info.request.type);
    if (info.rule.rulesetId === "stubs") e.stub = true;
    e.rules = e.rules || [];
    const rk = info.rule.rulesetId + "#" + info.rule.ruleId;
    if (!e.rules.includes(rk) && e.rules.length < 6) e.rules.push(rk);
    if (!e.sample) e.sample = info.request.url.slice(0, 200);
    if (!netTimer) netTimer = setTimeout(flushNetLog, 400);
  });
}
chrome.storage.onChanged.addListener((c, area) => { if (area === "local" && (c.allowHosts || c.devFlags)) applyAll(); });

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === "loading") {
    delete netLog[tabId];
    chrome.storage.session.remove([`tab_${tabId}`, `net_${tabId}`]);
    chrome.action.setBadgeText({ tabId, text: "" });
  }
});
chrome.tabs.onRemoved.addListener((tabId) => { delete netLog[tabId]; chrome.storage.session.remove([`tab_${tabId}`, `net_${tabId}`]); });

// Geheimes Entwickler-Menü: 5× schnell aufs Schild im AdShield-Fenster klicken
async function openDev(tab) {
  if (!tab || tab.id == null) [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const q = tab?.id != null ? `?tab=${tab.id}&url=${encodeURIComponent(tab.url || "")}` : "";
  chrome.tabs.create({ url: chrome.runtime.getURL("dev.html") + q, index: (tab?.index ?? 0) + 1, active: true });
}
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "open-dev-active") openDev({ id: msg.tabId, url: msg.url });
});

