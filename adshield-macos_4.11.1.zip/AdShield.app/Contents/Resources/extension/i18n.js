// Übersetzungen (Deutsch / Englisch) und gemeinsame Helfer für alle App-Seiten.
const STRINGS = {
  de: {
    status_green: "Alles läuft", status_yellow: "Läuft – mit Hinweisen",
    status_red: "Ausgeschaltet", status_black: "Fehler",
    status_green_sub: "Schutz ist aktiv und aktuell.",
    status_yellow_sub: "Werbung wird geblockt, aber nicht alles ist eingestellt.",
    status_red_sub: "Der Werbeblocker ist aus.",
    status_black_sub: "Etwas funktioniert nicht richtig.",
    issue_paused: "Der Werbeblocker ist pausiert.",
    issue_sites_off: "{n} von 5 Bereichen ohne Werbeblocker.",
    issue_never_updated: "Die Filter wurden noch nie aktualisiert.",
    issue_outdated: "Die Filter sind {n} Tage alt.",
    issue_update_failed: "Letztes Update fehlgeschlagen (kein Internet?). Die vorhandenen Regeln sind weiter aktiv.",
    issue_lists_partial: "Einige Filterlisten konnten nicht geladen werden.",
    issue_auto_off: "Automatische Updates sind ausgeschaltet.",
    issue_rules_error: "Die Regeln konnten nicht aktiviert werden.",
    issue_update_crashed: "Beim Verarbeiten der Filter ist ein Fehler passiert.",
    fix_update: "Jetzt aktualisieren", fix_enable: "Einschalten", fix_sites: "Alle Seiten an",
    fix_auto: "Auto-Updates an", fix_retry: "Erneut versuchen",
    protection: "Schutz", blocked_total: "Werbungen blockiert", today: "Heute", this_tab: "Dieser Tab",
    sites_protected: "Seiten geschützt", sites: "Seiten", blocked_n: "{n} blockiert", ad_blocker: "Werbeblocker",
    site_google: "Anzeigen & Shopping-Werbung ausblenden",
    site_youtube: "Video-Werbung automatisch überspringen",
    site_ytmusic: "Musik hören ohne Audio-Werbung",
    site_soundcloud: "Gesponserte Tracks & Werbung weg",
    site_other_name: "Alle anderen Webseiten",
    diag_title: "Blockierte Anfragen auf dieser Seite",
    diag_hint: "Seite geht nicht richtig? Erlaube hier einzelne Adressen, dann Seite neu laden (F5).",
    diag_empty: "Nichts blockiert. Seite neu laden und noch mal öffnen.",
    diag_allow: "Erlauben", diag_allowed: "Erlaubt ✓", diag_block: "blockiert", diag_stub: "ersetzt",
    site_other: "Werbung überall sonst blocken – z. B. auf Spiele-, Download- und News-Seiten",
    search_ph: "Mit Google suchen oder Adresse eingeben",
    greet_morning: "Guten Morgen", greet_day: "Guten Tag", greet_evening: "Guten Abend",
    home_tip: "Tipp: Über die Lesezeichenleiste oben kommst du jederzeit hierher zurück.",
    home_tip_chrome: "Tipp: Jeder neue Tab öffnet diese Seite. Und oben rechts beim Puzzle-Symbol kannst du AdShield anheften.",
    ob_tip_pin: "Klick oben rechts in Chrome auf das Puzzle-Symbol und hefte AdShield an – dann siehst du die Ampel immer.",
    reset_counter: "Zähler zurücksetzen", settings: "Einstellungen", home: "Startseite", back: "Zurück",

    set_status: "Status", set_lights: "Was die Farben bedeuten",
    light_green: "Alles an und aktuell.", light_yellow: "Läuft, aber etwas ist nicht ganz eingestellt.",
    light_red: "Der Werbeblocker ist aus.", light_black: "Es gibt einen Fehler.",
    no_issues: "Keine Probleme gefunden.",
    set_language: "Sprache", set_language_desc: "In welcher Sprache soll AdShield sprechen?",
    set_updates: "Updates", set_auto: "Automatisch aktualisieren",
    set_auto_desc: "Holt jeden Tag die neuesten Filterregeln. So passt sich AdShield an, wenn YouTube, SoundCloud & Co. ihre Werbung ändern.",
    set_check: "Jetzt nach Updates suchen", set_last_check: "Zuletzt geprüft",
    set_last_success: "Letztes Update", set_never: "Noch nie",
    set_network_rules: "Netzwerk-Regeln", set_cosmetic_rules: "Ausblende-Regeln",
    set_builtin: "+ eingebaute Regeln", set_lists: "Filterlisten",
    list_ok: "OK", list_failed: "Fehler", list_waiting: "—",
    upd_download: "Lade {name} …", upd_parse: "Regeln werden erstellt …", upd_apply: "Regeln werden aktiviert …",
    upd_done_new: "Fertig – {n} neue Regeln aktiv.", upd_done_same: "Alles aktuell – keine Änderungen.",
    upd_failed: "Update fehlgeschlagen – die eingebauten Regeln bleiben aktiv.",
    upd_crashed: "Fehler beim Verarbeiten der Filter.",
    set_general: "Allgemein", set_tutorial: "Tutorial erneut ansehen", set_version: "Version",
    ago_now: "gerade eben", ago_min: "vor {n} Min.", ago_h: "vor {n} Std.", ago_d: "vor {n} Tagen",

    ob_skip: "Überspringen", ob_next: "Weiter", ob_back: "Zurück", ob_start: "Los geht's",
    ob_welcome_title: "Willkommen bei AdShield",
    ob_welcome_text: "Werbefrei surfen – auf Google, YouTube, YouTube Music, SoundCloud und allen anderen Webseiten. In ein paar kurzen Schritten bist du startklar.",
    ob_choose_lang: "Wähle deine Sprache",
    ob_how_title: "So funktioniert's",
    ob_how_1_t: "Erkennen", ob_how_1: "AdShield erkennt Werbung auf der Seite und im Netzwerk.",
    ob_how_2_t: "Blockieren", ob_how_2: "Werbung wird blockiert, ausgeblendet oder übersprungen.",
    ob_how_3_t: "Aktualisieren", ob_how_3: "Jeden Tag holt AdShield neue Filterregeln aus dem Internet.",
    ob_lights_title: "Die Ampel",
    ob_lights_text: "Oben links siehst du immer, wie es AdShield gerade geht:",
    ob_sites_title: "Wo soll AdShield Werbung blocken?",
    ob_sites_text: "Du kannst das später jederzeit in den Einstellungen ändern.",
    ob_filters_title: "Filter laden",
    ob_filters_text: "AdShield holt jetzt die neuesten Filterregeln, damit der Schutz aktuell ist.",
    ob_filters_offline: "Kein Internet? Kein Problem – die eingebauten Regeln sind schon aktiv. AdShield versucht es später automatisch erneut.",
    ob_done_title: "Fertig! Du bist geschützt.",
    ob_done_text: "AdShield blockt ab jetzt Werbung für dich.",
    ob_tip_bookmarks: "Über die Lesezeichenleiste oben kommst du jederzeit zur Startseite.",
    ob_tip_settings: "Im Zahnrad findest du Sprache, Updates und den Status.",
    ob_tip_lights: "Leuchtet die Ampel nicht grün, zeigt dir AdShield, was zu tun ist.",
    ob_finish: "Zur Startseite"
  },
  en: {
    status_green: "All good", status_yellow: "Running – needs attention",
    status_red: "Turned off", status_black: "Error",
    status_green_sub: "Protection is on and up to date.",
    status_yellow_sub: "Ads are blocked, but not everything is set up.",
    status_red_sub: "The ad blocker is off.",
    status_black_sub: "Something isn't working right.",
    issue_paused: "The ad blocker is paused.",
    issue_sites_off: "{n} of 5 areas without ad blocking.",
    issue_never_updated: "Filters have never been updated.",
    issue_outdated: "Filters are {n} days old.",
    issue_update_failed: "Last update failed (no internet?). Existing rules are still active.",
    issue_lists_partial: "Some filter lists couldn't be downloaded.",
    issue_auto_off: "Automatic updates are turned off.",
    issue_rules_error: "The rules couldn't be activated.",
    issue_update_crashed: "Something went wrong while processing the filters.",
    fix_update: "Update now", fix_enable: "Turn on", fix_sites: "Turn on all sites",
    fix_auto: "Turn on auto-updates", fix_retry: "Try again",
    protection: "Protection", blocked_total: "Ads blocked", today: "Today", this_tab: "This tab",
    sites_protected: "Sites protected", sites: "Sites", blocked_n: "{n} blocked", ad_blocker: "Ad blocker",
    site_google: "Hide ads & shopping ads",
    site_youtube: "Skip video ads automatically",
    site_ytmusic: "Listen without audio ads",
    site_soundcloud: "No sponsored tracks or ads",
    site_other_name: "All other websites",
    diag_title: "Blocked requests on this page",
    diag_hint: "Page broken? Allow single addresses here, then reload (F5).",
    diag_empty: "Nothing blocked. Reload the page and open this again.",
    diag_allow: "Allow", diag_allowed: "Allowed ✓", diag_block: "blocked", diag_stub: "replaced",
    site_other: "Block ads everywhere else – games, downloads, news sites and more",
    search_ph: "Search Google or type an address",
    greet_morning: "Good morning", greet_day: "Good afternoon", greet_evening: "Good evening",
    home_tip: "Tip: Use the bookmarks bar at the top to come back here anytime.",
    home_tip_chrome: "Tip: Every new tab opens this page. Pin AdShield via the puzzle icon at the top right.",
    ob_tip_pin: "Click the puzzle icon at the top right of Chrome and pin AdShield – then you always see the status light.",
    reset_counter: "Reset counter", settings: "Settings", home: "Home", back: "Back",

    set_status: "Status", set_lights: "What the colors mean",
    light_green: "Everything on and up to date.", light_yellow: "Running, but something isn't fully set up.",
    light_red: "The ad blocker is off.", light_black: "There's an error.",
    no_issues: "No problems found.",
    set_language: "Language", set_language_desc: "Which language should AdShield use?",
    set_updates: "Updates", set_auto: "Update automatically",
    set_auto_desc: "Downloads the latest filter rules every day, so AdShield keeps up when YouTube, SoundCloud & co. change their ads.",
    set_check: "Check for updates now", set_last_check: "Last checked",
    set_last_success: "Last update", set_never: "Never",
    set_network_rules: "Network rules", set_cosmetic_rules: "Hiding rules",
    set_builtin: "+ built-in rules", set_lists: "Filter lists",
    list_ok: "OK", list_failed: "Failed", list_waiting: "—",
    upd_download: "Downloading {name} …", upd_parse: "Building rules …", upd_apply: "Activating rules …",
    upd_done_new: "Done – {n} new rules active.", upd_done_same: "Up to date – no changes.",
    upd_failed: "Update failed – built-in rules stay active.",
    upd_crashed: "Error while processing the filters.",
    set_general: "General", set_tutorial: "Show tutorial again", set_version: "Version",
    ago_now: "just now", ago_min: "{n} min ago", ago_h: "{n} h ago", ago_d: "{n} days ago",

    ob_skip: "Skip", ob_next: "Next", ob_back: "Back", ob_start: "Let's go",
    ob_welcome_title: "Welcome to AdShield",
    ob_welcome_text: "Browse ad-free – on Google, YouTube, YouTube Music, SoundCloud and every other website. You'll be ready in a few quick steps.",
    ob_choose_lang: "Choose your language",
    ob_how_title: "How it works",
    ob_how_1_t: "Detect", ob_how_1: "AdShield spots ads on the page and in the network.",
    ob_how_2_t: "Block", ob_how_2: "Ads get blocked, hidden or skipped.",
    ob_how_3_t: "Update", ob_how_3: "Every day AdShield fetches new filter rules from the internet.",
    ob_lights_title: "The status light",
    ob_lights_text: "Top left you'll always see how AdShield is doing:",
    ob_sites_title: "Where should AdShield block ads?",
    ob_sites_text: "You can change this anytime in Settings.",
    ob_filters_title: "Loading filters",
    ob_filters_text: "AdShield is now fetching the latest filter rules so your protection is up to date.",
    ob_filters_offline: "No internet? No problem – the built-in rules are already active. AdShield will try again automatically later.",
    ob_done_title: "Done! You're protected.",
    ob_done_text: "From now on AdShield blocks ads for you.",
    ob_tip_bookmarks: "Use the bookmarks bar at the top to get back to the home page anytime.",
    ob_tip_settings: "The gear icon has language, updates and status.",
    ob_tip_lights: "If the light isn't green, AdShield shows you what to do.",
    ob_finish: "Go to home"
  }
};

const UI = (() => {
  let lang = "de";

  function t(key, vars = {}) {
    const s = (STRINGS[lang] && STRINGS[lang][key]) ?? STRINGS.de[key] ?? key;
    return s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ""));
  }

  function apply(root = document) {
    document.documentElement.lang = lang;
    root.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
    root.querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
    root.querySelectorAll("[data-i18n-title]").forEach((el) => { el.title = t(el.dataset.i18nTitle); });
  }

  // Im normalen Google Chrome andere Tipps zeigen (keine AdShield-Lesezeichenleiste)
  const isGoogleChrome = (navigator.userAgentData?.brands || []).some((b) => b.brand === "Google Chrome");
  if (isGoogleChrome) {
    document.querySelectorAll('[data-i18n="home_tip"]').forEach((el) => { el.dataset.i18n = "home_tip_chrome"; });
    document.querySelectorAll('[data-i18n="ob_tip_bookmarks"]').forEach((el) => { el.dataset.i18n = "ob_tip_pin"; });
  }

  const listeners = [];
  async function init() {
    const s = await chrome.storage.sync.get({ lang: "" });
    lang = s.lang || ((navigator.language || "de").startsWith("de") ? "de" : "en");
    apply();
    chrome.storage.onChanged.addListener((c, area) => {
      if (area === "sync" && c.lang) {
        lang = c.lang.newValue || "de";
        apply();
        listeners.forEach((fn) => fn(lang));
      }
    });
    return lang;
  }

  const setLang = (l) => chrome.storage.sync.set({ lang: l });
  const onLang = (fn) => listeners.push(fn);
  const getLang = () => lang;

  const fmt = (n) => new Intl.NumberFormat(lang === "de" ? "de-DE" : "en-US").format(n || 0);

  function ago(ts) {
    if (!ts) return t("set_never");
    const min = Math.round((Date.now() - ts) / 60000);
    if (min < 1) return t("ago_now");
    if (min < 60) return t("ago_min", { n: min });
    const h = Math.round(min / 60);
    if (h < 24) return t("ago_h", { n: h });
    return t("ago_d", { n: Math.round(h / 24) });
  }

  // Status-Licht: <span class="light" data-level="green">
  function setLight(el, level) { if (el) el.dataset.level = level || "green"; }

  async function getStatus() {
    const { status } = await chrome.storage.local.get({ status: { level: "green", issues: [] } });
    return status;
  }

  function issueText(issue) { return t("issue_" + issue.code, { n: issue.n }); }

  return { t, apply, init, setLang, onLang, getLang, fmt, ago, setLight, getStatus, issueText };
})();
