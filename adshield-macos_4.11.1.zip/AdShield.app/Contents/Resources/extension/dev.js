const $ = (id) => document.getElementById(id);
const q = new URLSearchParams(location.search);
let tabId = q.get("tab") ? Number(q.get("tab")) : null;
let tabUrl = q.get("url") || "";
let report = "";

async function ruleText(rk, dyn) {
  const [set, id] = rk.split("#");
  if (set === "stubs") return "stubs#" + id + " (eingebaute Attrappe)";
  if (set === "_dynamic") {
    const r = dyn.find((x) => String(x.id) === id);
    const c = r?.condition || {};
    const pat = c.urlFilter || c.regexFilter || (c.requestDomains || []).join(",") || "?";
    return `Filterliste#${id} → ${r?.action?.type || "?"} ${pat}${c.domainType ? " [" + c.domainType + "]" : ""}`;
  }
  return set + "#" + id + " (eingebaut)";
}

async function pickTabs() {
  const all = (await chrome.tabs.query({})).filter((t) => /^https?:/.test(t.url || ""));
  all.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  const sel = $("tabSel"); sel.textContent = "";
  for (const t of all) {
    const o = document.createElement("option");
    o.value = t.id; o.textContent = (t.title || "").slice(0, 40) + " – " + (t.url || "").slice(0, 70);
    o.dataset.url = t.url; sel.appendChild(o);
  }
  if (tabId == null && all[0]) { tabId = all[0].id; tabUrl = all[0].url; }
  if (tabId != null) sel.value = String(tabId);
  sel.onchange = () => { tabId = Number(sel.value); tabUrl = sel.selectedOptions[0].dataset.url; render(); };
}

async function render() {
  const man = chrome.runtime.getManifest();
  $("ver").textContent = "v" + man.version;
  
  const [sync, local, dyn] = await Promise.all([
    chrome.storage.sync.get(null),
    chrome.storage.local.get(null),
    chrome.declarativeNetRequest.getDynamicRules()
  ]);
  const allow = local.allowHosts || [];
  let log = {};
  if (tabId != null) log = (await chrome.storage.session.get({ ["net_" + tabId]: {} }))["net_" + tabId];
  $("tabInfo").textContent = `Beobachteter Tab: ${tabId} · ${tabUrl}`;
  const hosts = Object.keys(log).sort((a, b) => log[b].n - log[a].n);
  const tb = $("net"); tb.textContent = ""; $("netEmpty").hidden = hosts.length > 0;
  const lines = [];
  for (const h of hosts) {
    const e = log[h];
    const rules = [];
    for (const rk of e.rules || []) rules.push(await ruleText(rk, dyn));
    const tr = document.createElement("tr");
    const td = (t) => { const c = document.createElement("td"); if (t instanceof Node) c.appendChild(t); else c.textContent = t; tr.appendChild(c); return c; };
    td(h).title = e.sample;
    const badge = document.createElement("span"); badge.className = "b " + (e.stub ? "stub" : "blk"); badge.textContent = e.stub ? "ersetzt" : "blockiert";
    td(badge);
    td(e.types.join(","));
    td(rules.join("\n") || "?").style.whiteSpace = "pre-wrap";
    td(String(e.n));
    const btn = document.createElement("button"); const ok = allow.includes(h);
    btn.textContent = ok ? "Erlaubt ✓" : "Erlauben"; btn.className = ok ? "on" : "";
    btn.onclick = async () => { await chrome.storage.local.set({ allowHosts: ok ? allow.filter((x) => x !== h) : [...allow, h] }); setTimeout(render, 600); };
    td(btn);
    tb.appendChild(tr);
    lines.push(`${e.stub ? "STUB " : "BLOCK"} ${h} x${e.n} [${e.types.join(",")}] ${rules.join(" | ")}\n        ${e.sample}`);
  }
  const status = local.status || {};
  const state = {
    version: man.version, ua: navigator.userAgent, settings: sync, devFlags: local.devFlags || {},
    status: { level: status.level, issues: status.issues },
    rulesError: local.rulesError || null, updateState: local.updateState || null,
    dynamicActive: local.dynamicActive, dynamicRules: dyn.length, allowHosts: allow,
    filterMeta: local.filterMeta ? Object.fromEntries(Object.entries(local.filterMeta).map(([k, v]) => [k, typeof v === "object" ? { ...v, text: undefined } : v])) : null
  };
  $("state").textContent = JSON.stringify(state, null, 2);
  report = `AdShield Dev-Bericht\nSeite: ${tabUrl || "-"}\n\n--- Anfragen ---\n${lines.join("\n") || "(keine)"}\n\n--- Status ---\n${JSON.stringify(state, null, 1)}`;
}
$("refresh").onclick = render;
$("allOff").onclick = async () => {
  const boxes = [...document.querySelectorAll("[data-flag]")];
  const on = !boxes.every((i) => i.checked);
  const f = {}; boxes.forEach((i) => { i.checked = on; f[i.dataset.flag] = on; });
  await chrome.storage.local.set({ devFlags: f });
  $("msg").textContent = (on ? "Alles AUS" : "Alles AN") + " – South Park mit F5 neu laden";
};
(async () => {
  const f = (await chrome.storage.local.get({ devFlags: {} })).devFlags;
  document.querySelectorAll("[data-flag]").forEach((i) => {
    i.checked = !!f[i.dataset.flag];
    i.onchange = async () => {
      const cur = (await chrome.storage.local.get({ devFlags: {} })).devFlags;
      cur[i.dataset.flag] = i.checked;
      await chrome.storage.local.set({ devFlags: cur });
      $("msg").textContent = "Gespeichert – jetzt South Park mit F5 neu laden";
    };
  });
})();
$("copy").onclick = async () => {
  try { await navigator.clipboard.writeText(report); $("msg").textContent = "Kopiert ✓ – jetzt im Chat einfügen"; }
  catch { $("msg").textContent = "Kopieren ging nicht – Text unten markieren"; }
};
pickTabs().then(render);
